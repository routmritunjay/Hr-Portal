<html>
<head>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" rel="stylesheet" type="text/css">
<style>
body {
    background: url(../../../login/img/login-bg.jpg) #fafafa;
    background-size: cover;
  }
.login-container {
    width: 350px;
    margin: 165px auto 0 auto;
    background: #fff;
    border-radius: 5px;
    padding: 30px 0px 0 0;
    -webkit-box-shadow: 0 6px 15px rgba(0, 0, 0, 0.16);
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.16);
}
  .login-container .row{margin: 0;}
  .logoblock {
	    background: #ebe8ff;
	    text-align: center;
	    padding: 140px 0 0 0;

	}
	.logoblock img{

	}
  .formblock{padding: 5px 40px 30px 30px; width: 100%;}
  input{outline: none;}
  .form-control:focus, .btn.focus, .btn:focus{box-shadow: none}
  .login-logo {
    margin: 0 0 30px 0;
}
  .login-logo img{ margin-left: -25px;}
</style>
</head>
<body class="login">
  <main>
  		
  	<div class="login-container">
  		<div class="row">
  		<div class="formblock">
  			<div class="text-center login-logo"><img src="<?php echo base_url(); ?>img/Logo.png" /></div>
  			<form method="post" autocomplete="off">
				<div class="form-group">
					<label for='email'>Email ID/Employee ID</label>
					<input class="form-control" type='text' name='email' id='email' placeholder="Enter Email Id or employeeID" />
					<p id="email_error" style="color:red;">
				</div>
				<div class="form-group">
					<label for='password'>Password</label>
					<input class="form-control" type='password' name='password' id='pwd' placeholder="Enter Pasword" />
					<p id="pwd_error" style="color:red;">
				</div>
				<button type="submit" class="btn btn-primary" id="btn_submit">Login</button>
				<p id="pid" style="color:red;"></p>
				<a href="<?php echo base_url(); ?>Forgot_password">Forgot Password</a>
          	</form>
  		</div>
  	</div>
  	</div>
  </main>

  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.1/jquery.min.js"></script>
  <script>
	$(document).ready(function(){

		$(".form-group").on('keyup change',function(){

  				$("#email_error,#pwd_error,#pid").html('');

		});

$(document).on('click','#btn_submit',function(event){

            event.preventDefault();

			var email = $("#email").val();

			var password = $("#pwd").val();

			var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
			var errors = "";
			if(email == ""){

			errors = "Please Enter EmployeeID/Email";

			$("#email_error").html(errors);

			}
			else if(!validateemail(email) && !$.isNumeric(email)){

			 errors = "Invalid Credentials Provided!";

			  $("#pwd_error").html(errors);

		   }	
			else if(password == ""){

			  $("#email_error").empty();

			errors = "Password cannot be empty!";

			$("#pwd_error").html(errors);

			}
			else if(email != "" && password != ""){

			  $("#pwd_error,#email_error").empty();

				$.ajax({

				  	type:"POST",

					url:"<?php echo base_url(); ?>Login/checklogin",

				 	data:{"email":email,"password":password},

				    dataType:'json',

				    contentType: 'application/x-www-form-urlencoded',

				success:function(response){

					console.log(response);

				  $("#pid").empty();

				    if(response){

				    	if(response.success == false){

				           $("#pid").append(response.message);

				    	}else if(response.success == true){

				    		window.location.href = 'dashboard';

				    	}
				}else if(response == "false"){
				  $("#pid").append("Invalid username or password");
				}
				}
			});
			}
	 	});
	});



	function validateemail(sEmail){
var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
if (filter.test(sEmail)) {
        return true;
    }else{
        return false;
    }
	}
</script>
</body>
</html>