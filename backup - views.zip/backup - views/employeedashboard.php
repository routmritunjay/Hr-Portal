<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Łukasz Holeczek">
    <meta name="keyword" content="">

    <link rel="shortcut icon" href="images/favicon.png">
    <title>Intelexsystemsinc.com</title>

    <!-- Icons -->
    <link href="vendors/css/font-awesome.min.css" rel="stylesheet">
    <link href="vendors/css/simple-line-icons.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Main styles for this application -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/dashboard.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.5/jquery.bxslider.css">

    <!-- Styles required by this views -->
    <style type="text/css">
        /* Carousel Header Styles */
        
        .header-text {
            position: absolute;
            top: 20%;
            left: 1.8%;
            right: auto;
            width: 96.66666666666666%;
            color: #fff;
        }
        
        .header-text h2 {
            font-size: 40px;
        }
        
        .header-text h2 span {
            background-color: #2980b9;
            padding: 10px;
            margin-left: 190px;
        }
        
        .header-text h3 span {
            background-color: #000;
            padding: 15px;
            margin-left: 110px;
        }
        
        .carousel-inner img {
            width: 100%;
            max-height: 460px
        }
        
        .carousel-control {
            width: 0;
        }
        
        .carousel-control.left,
        .carousel-control.right {
            opacity: 1;
            filter: alpha(opacity=100);
            background-image: none;
            background-repeat: no-repeat;
            text-shadow: none;
        }
        
        .carousel-control.left span {
            padding: 15px;
        }
        
        .carousel-control.right span {
            padding: 15px;
        }
        
        .carousel-control .glyphicon-chevron-left,
        .carousel-control .glyphicon-chevron-right,
        .carousel-control .icon-prev,
        .carousel-control .icon-next {
            position: absolute;
            top: 45%;
            z-index: 5;
            display: inline-block;
        }
        
        .carousel-control .glyphicon-chevron-left,
        .carousel-control .icon-prev {
            left: 0;
        }
        
        .carousel-control .glyphicon-chevron-right,
        .carousel-control .icon-next {
            right: 0;
        }
        
        .carousel-control.left span,
        .carousel-control.right span {
            background-color: #000;
        }
        
        .carousel-control.left span:hover,
        .carousel-control.right span:hover {
            opacity: .7;
            filter: alpha(opacity=70);
        }
        /* Carousel Header Styles */
        
        .header-text {
            position: absolute;
            top: 20%;
            left: 1.8%;
            right: auto;
            width: 96.66666666666666%;
            color: #fff;
        }
        
        .header-text h2 {
            font-size: 40px;
        }
        
        .header-text h2 span {
            background-color: #2980b9;
            padding: 10px;
        }
        
        .header-text h3 span {
            background-color: #000;
            padding: 15px;
        }
    </style>
    </style>

</head>

<body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
    <div class="app-body">
        <!-- Main content -->
        <main class="main mainbg">
            <!-- Breadcrumb -->
            <ol class="breadcrumb breadcrumbbg">
                <li class="breadcrumb-item">Home</li>
                <li class="breadcrumb-item">Employee</li>
                <li class="breadcrumb-item active">Dashboard</li>
            </ol>

            <div class="container-fluid dashboradbg">
                <div class="animated fadeIn">
                    <div class="row">
                        <div class="col-sm-3 col-lg-3">
                            <div class="card emp_policy">
                                <div class="card-body pb-0">
                                    <h4 class="mb-0">Employee Policies</h4>
                                    <p>Document</p>
                                </div>
                                <input type="hidden" id="vals" value="<?php echo $email; ?>">
                                <?php foreach ($details as $details) { ?>
                                    <button type="button" class="btn_dashbaordpanel" onclick="window.location.href='viewpolicies'">View</button>
                                    <?php } ?>
                            </div>
                        </div>
                        <!--/.col-->

                        <div class="col-sm-3 col-lg-3">
                            <div class="card laeve_application">
                                <div class="card-body pb-0">
                                    <h4 class="mb-0">Leave Applications</h4>
                                    <p>Employees on Leave</p>
                                </div>
                                 <button class="btn_dashbaordpanel color_red" onclick="window.location.href='Employeedashboard/Leave'">Apply</button>
                                    </button>
                            </div>
                        </div>
                        <!--/.col-->

                        <div class="col-sm-3 col-lg-3">
                            <div class="card employee_count">
                                <div class="card-body pb-0">
                                    <div class="btn-group float-right">
                                    </div>
                                    <h4 class="mb-0">Employee</h4>
                                    <p>Total Employee Count</p>
                                </div>
                                <button class="btn_dashbaordpanel color_purple">
                                    <?php echo $total_emp_count; ?>
                                </button>
                            </div>
                        </div>
                        <!--/.col-->
                        <!--/.col-->
                        <div class="col-sm-3 col-lg-3">
                            <div class="card inquery">
                                <div class="card-body pb-0">
                                    <div class="btn-group float-right">
                                    </div>
                                    <h4 class="mb-0">Inquiries</h4>
                                    <p>Total Inquiry Count</p>
                                </div>
                                <button class="btn_dashbaordpanel color_blue">
                                    <?php echo $inquiries_count; ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="row dashbaord_timelines">
                        <div class="col-sm-4 col-md-4 col-lg-4">
                           <div class="card">
                               <h4 style="text-align: center;">Today/Upcoming Birthday's</h4>
                               <div id="thumbCarousel" class="carousel slide">
                                   <div class="carousel-inner">
                                   <?php $i=0; if(!empty($birthday_result)){ foreach($birthday_result as $val){?>
                                    <?php $img_src = ($val->profile_photo != "") ? $val->profile_photo : 'assests/employee_image/defult_profile.png'; ?>
                                       <div class="item <?php if($i == 0){echo 'active';}?>">
                                           <img class="d-block w-100" src="<?php echo $img_src; ?>" style="height:200px;">
                                           <div class="card-body">
                                               <h3 class="card-title"><?php echo $val->first_name.$val->last_name ?></h3>
                                               <p class="card-text"><?php echo $val->dob; ?></p>
                                           </div>
                                       </div>
                                   <?php $i++; } }else{?>
                                   <div class="item <?php if($i == 0){echo 'active';}?>">
                                          <?php $img_src = 'assests/employee_image/smiley_PNG36226.png'; ?>
                                           <img class="d-block w-100" src="<?php echo $img_src; ?>" style="height:200px;">
                                           <div class="card-body">
                                               <h4 class="card-title">No Upcoming Birthday's</h4>
                                           </div>
                                       </div>
                                   <?php } ?>
                                   </div>

                                   <p style="text-align:center;">
                                       <a class="thumbleft" href="#thumbCarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
                                       <a class="thumbright" href="#thumbCarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span> </a>
                                   </p>
                               </div>
                           </div>
                       </div>
                         <!-- /carousel -->
                        

                        <div class="col-sm-4 col-lg-4">
                            <div class="card">
                                <h4 style="text-align: center;">Upcoming Leave</h4>
                                <!-- Carousel -->
                                    <ul class="list-group-leaves">
                                        <?php $i=0; if(!empty($upcoming_leave_res)){ foreach($upcoming_leave_res as $val){?>
                                        <li class="item">
                                             <?php if($val->profile_photo != "") { ?>
                                                <img class="d-block" src="<?php echo $val->profile_photo;?>" style="height:50px;width:50px;">
                                            <?php } else{ ?>
                                            <img class="d-block " src="<?php echo base_url();?>assests/employee_image/smiley_PNG36226.png" style="height:50px;width:50px;">
                                            <?php } ?>
                                            <p><?php echo $val->first_name." ".$val->last_name;?></p>
                                            <p><?php echo $val->leave_from_date ." - ".$val->leave_to_date ; ?></p>
                                        </li>
                                        <?php }} else { ?>
                                        <h3 style="font-weight:bold; text-align:center;">No Records Found</h3>
                                        <?php } ?>
                                    </ul>
                            </div>
                        </div>
                        <!-- /carousel -->
                        <div class="col-sm-4 col-lg-4">
                            <div class="card">
                                <h4 style="text-align: center;">Upcoming Events</h4>
                                <div id="eventcarousel" class="carousel slide">
                                    <div class="carousel-inner">
                                        <?php $i=0;  if(!empty($event)){ foreach($event as $val){?>
                                            <div class="item <?php if($i == 0){echo 'active';}?>">
                                                <img class="d-block w-100" src="https://mdbootstrap.com/img/Photos/Slides/img%20(47).jpg" style="height:200px;">
                                                <div class="card-body">
                                                    <h3 class="card-title"><?php echo $val->type;?></h3>
                                                    <p class="card-text"><?php echo $val->event_date; ?></p>
                                                    <p class="card-text"><?php echo $val->event_desc; ?></p>
                                                </div>
                                            </div>
                                        <?php $i++; } ?>
                                    </div>
                                    <?php if($i > 1){ ?>
                                    <p style="text-align:center;">
                                        <a class="thumbleft" href="#eventcarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
                                        <a class="thumbright" href="#eventcarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span> </a>
                                    </p>
                                    <?php } } else { ?>
                                        <h3 style="font-weight:bold; text-align:center;">No Records Found</h3>
                                    <?php } ?>
                                    </div>
                                </div>
                        </div>
                       <!--  <div class="col-sm-3 col-lg-3">
                            <div class="card">
                                <h4 style="text-align: center;">Heading</h4>
                            </div>
                        </div> -->
                    </div>
        </div>
    </div>
    </div>
    <!-- /.conainer-fluid -->
    </main>
    </div>

    <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>

    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="vendors/js/pace.min.js"></script>

    <!-- Plugins and scripts required by all views -->
    <script src="vendors/js/Chart.min.js"></script>
    <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <!-- Leaf Lite main scripts -->

    <script src="js/app.js"></script>

    <!-- Plugins and scripts required by this views -->

    <!-- Custom scripts required by this view -->
    <script src="js/views/main.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.5/jquery.bxslider.min.js"></script>
    <script>
        $(document).ready(function() {
                $('.today_birthday').slick();
                $('.up_birthday').slick();
                $('.up_leave').slick();
                $('.event').slick();
        var reset_url = "";

        $('.nav-link').each(function() {
            var url = $('#url').val();
            if (url == $(this).attr('href')) {

                $(this).addClass("active");
            }

        });


    });



    </script>

</body>

</html>