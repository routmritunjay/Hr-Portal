<html>
   <head>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
   </head>
   <table style="width: 600px;    padding: 0 0 0 112px;">
      <tr>
         <td style="width: 10%">
         </td>
         <td>
            <img src="<?php echo base_url();?>img/logo2.png" alt="Intellex logo">
         </td>
         <td>
         </td>
      </tr>
      <tr>
         <td></td>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
         <td></td>
      </tr>
   </table>
   <table style="width: 600px ;    border-radius: 9px;
      padding: 20px;
      width: 596px;
      height: 33px;
      border: 1px solid #e4ecf0;    border-top: 5px solid #119ed5;">
   <tr>
      <td>
         <span style=" font-family: Arial;font-size: 15px">
            <span><?php echo $subject; ?></span>
            <hr>
            Please check in HR Portal for updates.
         </span>
      </td>
   </tr>
</html>