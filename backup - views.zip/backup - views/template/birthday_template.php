<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
</head>
<style>
      @import url('https://fonts.googleapis.com/css?family=Prata&display=swap" rel="stylesheet');
  </style>
<body>
    <section class="background-img" style="background: url('http://web.intelexstagingurl.com/login/template_image/birthday-bg.png') no-repeat;height: 800px;">
<div style="width: 50%">
<h2 style="text-align: center;padding: 62px 0 0 0; font-family: 'Prata', serif;color: #e44787;    text-transform: uppercase;    margin-bottom: 0;    font-size: 25px;font-weight: 500;">Hi <?php echo $full_name; ?>
<p style="text-align: center;padding: 0px 0 0 0; font-family: 'Prata', serif;margin-top: 10px;color: #005f81;    font-size: 22px;">We Wish You a Very Happy Birthday....</p>
</div>
</section>
</body>
</html>