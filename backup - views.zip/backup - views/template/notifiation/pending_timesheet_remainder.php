<html>
   <head>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
   </head>
   <table style="width: 600px;    padding: 0 0 0 112px;">
      <tr>
         <td style="width: 10%">
         </td>
         <td>
            <img src="<?php echo base_url();?>img/logo2.png" alt="Intellex logo">
         </td>
         <td>
         </td>
      </tr>
      <tr>
         <td></td>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
         <td></td>
      </tr>
   </table>
   <table style="width: 600px ;    border-radius: 9px;
      padding: 20px;
      width: 596px;
      height: 33px;
      border: 1px solid #e4ecf0;    border-top: 5px solid #119ed5;">
   <tr>
      <td>
         <span style=" font-family: Arial;font-size: 15px">
         <?php if($remainder_type == 1){?>

         <span>Hi Sreenath,<br></span>

         <span>Please view the below attachment which contains all the list of employees whose timesheet are awaiting for approval from your end.</span><hr>

         Please check in HR Portal for updates and request you to approve/reject for below timesheet.

         <?php }else if($remainder_type == 0){ ?>

          <span>Hi Sreenath,<br></span>

         <span>There are no pending employee timesheet to be approved/reject from your side.</span><hr>

         Please check in HR Portal for updates.

         <?php } ?>
         </span>
      </td>
   </tr>
</html>