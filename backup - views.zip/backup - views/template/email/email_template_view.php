<html>
   <head>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
   </head>
   <table style="width: 600px;    padding: 0 0 0 112px;">
      <tr>
         <td style="width: 10%">
         </td>
         <td>
            <img src="<?php echo base_url();?>img/logo2.png" alt="Intellex logo">
         </td>
         <td>
         </td>
      </tr>
      <tr>
         <td></td>
         <td></td>
         <td></td>
      </tr>
      <tr>
         <td></td>
         <td></td>
         <td></td>
      </tr>
   </table>
   <table style="width: 600px ;    border-radius: 9px;
      padding: 20px;
      width: 596px;
      height: 33px;
      border: 1px solid #e4ecf0;    border-top: 5px solid #119ed5;">
   <tr>
      <td>
         <span style=" font-family: Arial;font-size: 15px">
         <?php  if($leave_type_res == 'empreqs'){?>

         <span><?php echo $mssg; ?></span><hr>

         <span style="font-size: 15px;font-family:Arial">Kind Regards,</span><br>

         <span style="font-size: 15px;font-family:Arial"><?php echo $name; ?>.</span>

         <?php }else if($leave_type_res == "mapprove"){ ?>
         Hi <?php echo $name; ?>,<br>Your Leave Application from <?php echo $start_date; ?> to <?php echo $end_date; ?>(<?php echo $leave_type; ?>) has been <?php echo ucwords($leave_status); ?> By Your Manager -  <?php echo $approved_by;?>.<br><br>
         <p><b>Comments</b>:<?php echo $comments; ?></p>
         Please check in HR Portal for updates.
         <?php } else if($leave_type_res == "pmoapprove"){ ?>
         Hi <?php echo $name; ?>,<br>Your Leave Application From <?php echo $start_date; ?> to <?php echo $end_date; ?> () has been  By PMO - <?php echo $approved_by;?>.<br><br>
         Please check in HR Portal for updates.
         <?php } else if($leave_type_res == "ceoapprove"){ ?>
         Hi <?php echo $name; ?>,<br>Your Leave Application From <?php echo $start_date; ?> to <?php echo $end_date; ?> (<?php echo $leave_type; ?>) has been <?php echo ucwords($leave_status); ?> By CEO - <?php echo $approved_by; ?>.<br><br>
         <p><b>Comments</b>:<?php echo $comments; ?></p>
         Please check in HR Portal for updates.
         <?php } ?>
         </span>
      </td>
   </tr>
</html>