<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
</head>
<style>
    @import url('https://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900&display=swap');
    @import url('"https://fonts.googleapis.com/css?family=Oswald&display=swap');
    @import url('"https://fonts.googleapis.com/css?family=Open+Sans&display=swap');
</style>

<body style="    ">
    <div class="outer-wrap" style="width: 800px;border: 1px solid #c6c6c6; border-top: 5px solid #119ed5; border-radius: 10px;">
    
        <div style="padding: 30px;">
            <h2 style="text-align: center;color: #000000;    font-family: 'Myriad Pro Regular';font-size: 28px; ">Hi Team,</h2>
            <p style="color: #1a1a1a;text-align: center;    padding: 0 40px 0 40px;    font-size: 20px;    font-family: 'Raleway', sans-serif; font-weight: 500; line-height: 19px;">We have following Event today</p>
            <div style="background-color: #119ed5; margin: 40px 0 0 0;">
                <table style="width:100%;  padding: 9px 0 9px 0;">
                    <tr style="color: #fff;">

                        <th
                            style="width:20%;text-align:center;font-size: 15px;font-family: 'Myriad Pro Regular';font-weight: 100;">
                            DATE
                        </th>
                        <th
                            style="width:16%;text-align:center;font-size: 15px; font-family: 'Myriad Pro Regular';font-weight: 100;">
                            TIME
                        </th>
                        <th
                            style="width:15%;text-align:center;font-size: 15px;font-family: 'Myriad Pro Regular';font-weight: 100;">
                            VENUE
                        </th>

                    </tr>
                </table>



                <table style="width:100%;  padding: 9px 0 9px 0; background-color: #e9e9e9;">
                    <tr style="color: #000;">

                        <th
                            style="width:20%;text-align:center;font-size: 15px;font-family: 'Myriad Pro Regular';font-weight: 100;">
                            08-11-2019
                        </th>
                        <th
                            style="width:16%;text-align:center;font-size: 15px; font-family: 'Myriad Pro Regular';font-weight: 100;">
                            06:00PM
                        </th>
                        <th
                            style="width:15%;text-align:center;font-size: 15px;font-family: 'Myriad Pro Regular';font-weight: 100;">
                            INTELEX
                        </th>

                    </tr>
                </table>



            </div>
            <br>
            <p style="color:#2d2d2d; text-align: center; padding: 0 0 0 0; font-size: 30px; font-family: 'Tahu!', sans-serif; font-weight:500;">Let's gear up for Friday Fun Activity.</p>
                    <p style="text-align: center;color: #03496b;font-family: 'Oswald', sans-serif; font-size: 18px;">-REGARDS-</p>
        <p style="text-align: center;margin: 0;"><img src="./logo.png" alt="pds logo" style="width: 20%; padding:0 0 10px 0;">
     </p>
        </div>

    </div>
</body>
</html>