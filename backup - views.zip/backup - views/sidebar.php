<div class="sidebar">
   <?php $url_view = explode('/',$_SERVER['REQUEST_URI']); 
      $final_url_view = end($url_view);
      ?>
   <nav class="sidebar-nav">
      <ul class="nav">
         <?php $role; if(ISSET($role)) { ?>

         <!-- common dashboard -->

         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "dashboard"){echo("active");} ?>" href="<?php echo base_url(); ?>dashboard"><i class="fa fa-tachometer" aria-hidden="true"></i> Dashboard </a>
         </li>

         <!-- employee & manager sidebar -->
         <?php if($role == 2 || $role == 0) { ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "leave" || $final_url_view == "Leave" || $final_url_view == "Available_leave"){echo("active");} ?>" href="<?php echo base_url();?>leave"><i class="fa fa-envelope" aria-hidden="true"></i> Leave Requests</a>
         </li>
         <?php if($role == 2) { ?> 
         <li class="nav-item"><a class="nav-link" <? ($final_url_view == "employeeleaves") ? "active" : "" ?>"  href="<? base_url() ?>employeeleaves"><i class="fa fa-envelope-open-o" aria-hidden="true"></i>Employee Leaves</a></li>
         <? } ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "employee-payslip"){echo("active");} ?>" href="<?php echo base_url();?>employee-payslip"><i class="fa fa-file" aria-hidden="true"></i>Payslip</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Timesheet" || $final_url_view == "task_entry"){echo("active");} ?>" href="<?php echo base_url();?>Timesheet"><i class="fa fa-bell" aria-hidden="true"></i>Timesheet</a>
         </li>
         <?php if($role == 2) { ?>
         <li class="nav-item">
            <a class="nav-link <?php echo ($final_url_view == "Employee_project") ? "active" : ""; ?>" href="<? base_url() ?>Employee_project"><i class="fa fa-bell" aria-hidden="true"></i>Employee Timesheet</a>
         </li>
         <?php } ?>
         <?php if($role == 0) { ?> 
         <li class="nav-item">
            <a class="nav-link <? echo ($final_url_view == "work_tracker") ? "active" : "" ?>" href="<? base_url() ?>work_tracker"><i class="fa fa-tasks" aria-hidden="true"></i>Work Tracker</a>
         </li>
         <? } ?>
         <?php if($role == 2) { ?> 
         <li class="nav-item">
            <a class="nav-link <? echo ($final_url_view == "work_tracker") ? "active" : ""; ?>" href="<? base_url() ?>work_tracker"><i class="fa fa-tasks" aria-hidden="true"></i>Employee Work Tracker</a>
         </li>
         <?php } ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Employee_attendence"){echo("active");} ?>" href="<?php echo base_url();?>Employee_attendence"><i class="fa fa-clock-o" aria-hidden="true"></i>Attendance</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "HolidayList"){echo("active");} ?>" href="<?php echo base_url();?>HolidayList"><i class="fa fa-list"></i>Holiday List</a>
         </li>
         <?php } ?>


         <!-- pmo,ceo,founder,hr & admin sidebar -->


         <?php  if($role == 1 || $role == 5 || $role == 3 || $role == 4 || $role == 7|| $role == 6){?>

         <?php if($role == 1 || $role == 7 || $role == 4){?>

         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Admin"){echo("active");} ?>" href="<?php echo base_url();?>Admin"><i class="fa fa-user-circle"></i> Admin </a>
         </li>

         <?php } ?>

         <?php if($role != 6){?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Roles"){echo("active");} ?>" href="<?php echo base_url();?>Roles"><i class="fa">&#xf2ba;</i>Roles</a>
         </li>
         <?php } ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Hrpolicies"){echo("active");} ?>" href="<?php echo base_url();?>Hrpolicies"><i class="fa fa-flag" aria-hidden="true"></i> HR Policies</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Admin_usermanagement" || $final_url_view == "Employeadd"){echo("active");} ?>" href="<?php echo base_url();?>Admin_usermanagement"><i class="fa fa-user" aria-hidden="true"></i> Employee Management</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Resume"){echo("active");} ?>" href="<?php echo base_url();?>Resume"><i class="fa fa-linkedin" aria-hidden="true"></i>Resume DB</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Career"){echo("active");} ?>" href="<?php echo base_url();?>Career"><i class="fa fa-briefcase" aria-hidden="true"></i>Careers</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Addjobrole"){echo("active");} ?>" href="<?php echo base_url();?>Career/Addjobrole"><i class="fa fa-laptop"></i>Technology</a>
         </li>
         <li class="dropdown nav-item">
            <a href="#" class="dropdown-toggle nav-link <?php if($final_url_view == "Leave" || $final_url_view == "Leavetype" || $final_url_view == "Employeeleave" || $final_url_view == "RestrictedHoliday"){echo("active");} ?>" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-envelope" aria-hidden="true"></i>Leave Requests<span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
               <li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>Leave"></i>Employee Leaves</a></li>
               <?php if($role == 1 || $role == 5 || $role == 3 || $role == 4  || $role == 7) { ?>
               <li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>Leave/Leavetype"></i>Leave Type</a></li>
               <li class="nav-item"><a class="nav-link" href="<?php echo base_url();?>Leave/Employeeleave"></i>Employee Remaining Leaves</a></li>
               <?php } ?>
            </ul>
         </li>
         <?php if($role == 1 || $role == 5 || $role == 3 || $role == 4  || $role == 7 || $role == 6) { ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Payslips"){echo("active");} ?>" href="<?php echo base_url();?>Payslips"><i class="fa fa-file" aria-hidden="true"></i> Payslips</a>
         </li>
         <?php } ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Attendence"){echo("active");} ?>" href="<?php echo base_url();?>Attendence"><i class="fa fa-clock-o" aria-hidden="true"></i>Attendance</a>
         </li>
         <?php if($role == 7){ ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "project"){echo("active");} ?>" href="<?php echo base_url();?>project"><i  class='fa fa-briefcase'></i>Project</a>
         </li>
         <?php } ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Employee_timesheet"){echo("active");} ?>" href="<?php echo base_url();?>Employee_timesheet"><i class="fa fa-bell"></i>Employee Timesheet</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "work_tracker"){echo("active");} ?>" href="<?php echo base_url();?>work_tracker"><i class="fa fa-tasks" aria-hidden="true"></i>Employee Work Tracker</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "HolidayList"){echo("active");} ?>" href="<?php echo base_url();?>HolidayList"><i class="fa fa-list"></i>Holiday List</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Events"){echo("active");} ?>" href="<?php echo base_url();?>Events"><i class="fa fa-list"></i>Events</a>
         </li>
         <?php if($role != 6 && $role != 1 && $role != 3 && $role != 5){ ?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "notification"){echo("active");} ?>" href="<?php echo base_url();?>notification"><i class="fa fa-list"></i>Notification</a>
         </li>
         <?php } ?>
        
         <?php if($role == 3 || $role == 6){?>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "leave" || $final_url_view == "Leave" || $final_url_view == "Available_leave"){echo("active");} ?>" href="<?php echo base_url();?>Employeedashboard/leave"><i class="fa fa-envelope" aria-hidden="true"></i> Apply Leave </a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Employeedashboard/payslip"){echo("active");} ?>" href="<?php echo base_url();?>Employeedashboard/payslip"><i class="fa fa-file" aria-hidden="true"></i>Payslip Module</a>
         </li>
         <li class="nav-item">
            <a class="nav-link <?php if($final_url_view == "Timesheet" || $final_url_view == "task_entry"){echo("active");} ?>" href="<?php echo base_url();?>Timesheet"><i class="fa fa-list-alt"></i>Timesheet</a>
         </li>
         <?php } ?>
         <?php } ?>
         <?php } ?>
      </ul>
   </nav>
</div>