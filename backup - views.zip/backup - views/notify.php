<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <!-- Styles required by this views -->
      <style>
         select:invalid { color: gray; };
         .shadow-textarea textarea.form-control::placeholder {font-weight: 300;}
         .shadow-textarea textarea.form-control {padding-left: 0.8rem;}
      </style>
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Dashboard</li>
               <li class="breadcrumb-item active">notifications</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Add Notifications</div>
                           <div class="panel-body" style="overflow: hidden;">
                              <form name="MyForm" autocomplete="off" id="form_dt">
                                <div class="row">
                                   <input type="hidden" id="notify_id">
                                    <input type="hidden" id="up_type" value="submit">
                                    <div class="form-group col-md-4">
                                      <label for="email">Send To</label>
                                      <select type="select" class="form-control send_to">
                                        <option value="none">Select An Option</option>
                                        <option value="1">ALL</option>
                                        <option value="0">LEADS</option>

                                        </select>                                     
                                    </div>
                                 </div>
                                 <div class="row">
                                      <div class="form-group col-md-4">
                                      <label for="email">Heading</label>
                                       <input type="text" id="form1" class="heading form-control" class="form-control" placeholder="Enter Heading">
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="form-group col-md-12">
                                       <label for="email">Subject</label>
                                       <textarea class="form-control" placeholder="Enter message" name="editor1" id="editor1" required></textarea>
                                    </div>
                                 </div>
                                 <div class="form-group col-md-12" style="clear: both;">
                                    <input type="button" class="btn btn-success common_add" id="notify" value="Submit Request">
                                    <p id="leave_errors" style="color:red; font-size:15px;"></p>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <p id="ins_errors" style="color:red;"></p>
                     <div class="panel panel-default">
                        <div class="panel-heading">Tasks Records</div>
                        <div class="panel-body">
                           <table class="table table-bordered myTable">
                              <thead>
                                 <tr>
                                    <th scope="col">Send To</th>
                                    <th scope="col">Heading</th>
                                    <th scope="col">Subject</th>
                                    <th scope="col">Updated-on</th>
                                    <th scope="col">Action</th>
                                 </tr>
                              </thead>
                              <tbody id="tdetails">
                                 <?php foreach($notify as $notify){ ?>
                                 <tr>
                                    <td><?php echo ($notify->send_to == 1)?'ALL':'LEADS'; ?></td>
                                    <td><?php echo $notify->heading; ?></td>
                                    <td><button type="button" class="btn btn-default" onclick = "getmssgdetails('<?php echo $notify->id;?>')">View</button></td>
                                    <td><?php echo date('d-m-y',$notify->updated_on); ?></td>
                                    <td><a><i class="fa fa-edit green" aria-hidden="true" onclick="edit_notify('<?php echo $notify->id; ?>')"></i></a>                     
                                       <i class="fa fa-trash red" aria-hidden="true" onclick="comment_delete_func('<?php echo $notify->id; ?>','notify')"></i>
                                    </td>
                                 </tr>
                                 <?php } ?>
                              </tbody>
                           </table>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </main>
      </div>
      <div class="modal fade" id="myModalx" role="dialog" style="width:100%;">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <h4 class="modal-title">Subject</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
               </div>
               <div class="modal-body">
                  <p id="view_mssg"></p>
               </div>
               <div class="modal-footer">
               </div>
            </div>
         </div>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <!-- Leaf Lite main scripts -->
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8.13.6/dist/sweetalert2.all.min.js"></script>
      <script src="<?php echo base_url();?>assests/ajaxjs/insertajax.js"></script>
      <script src="<?php echo base_url();?>assests/ajaxjs/common_delete_ajax.js"></script> 
      <script>
         var editor = CKEDITOR.replace( 'editor1' );
         
         $(document).ready( function () {
         
            var dataTable = $('.myTable').DataTable({

            	"aaSorting": [],

            });

         
            $('.datepicker').datepicker({
         
             format: 'dd-mm-yyyy',
         
          });
         
          });
         
   
           
         
         function getmssgdetails(id,name){
         
            $.ajax({
         
           type:"POST",
         
           url:"<?php echo base_url(); ?>Employeedashboard/get_notification_subject",
         
           data:{
         
             "id":id
         
          },
         
           dataType:'json',
         
         success:function(response){
         
           console.log(response);
         
           $.each(response,function(key,value){
         
             $("#view_mssg").html(value.subject);
         
           });
         
           $("#myModalx").modal('show');
         
         }
         
         });
         
         }
         
         
         
         $("#reset_opt").click(function(){
         
         location.reload();
         
         });
         
         
         
         
         
         function edit_notify(id){
         
           $.ajax({
         
             type:"POST",
         
               url:"<?php echo base_url();?>Employeedashboard/get_single_notify",
         
            data:{
         
               "id":id,
         
           },
         
                 dataType:'json',
         
           success:function(response){
         
             console.log(response);

             $(".send_to").empty();
         
           $.each(response,function(key,value){

            var option = (value.send_to == 1)? '<option value = "'+value.send_to+'">All</option><option value = "0">LEADS</option>' : '<option value = "'+value.send_to+'">All</option> <option value = "1">ALL</option>'
         
             $("#notify_id").val(value.id);

             $(".send_to").append(option);

             $(".heading").val(value.heading);
         
             CKEDITOR.instances['editor1'].setData(value.subject)
         
             $(".panel-heading").text('Edit Notification');
         
             $("#notify").val('Update Request');

             $("#up_type").val('update');
                  
           });
         
           }
         
           });
         
         }
         
      </script>
   </body>
</html>