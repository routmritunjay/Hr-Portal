 <!DOCTYPE html>

 <html lang="en">

 <head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">

   

   <meta http-equiv="X-UA-Compatible" content="IE=edge">

   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

   <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">

   <meta name="author" content="Łukasz Holeczek">

   <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">

   <link rel="shortcut icon" href="images/favicon.png">

   <title>Intelexsystemsinc.com</title>

 

   <!-- Icons -->

   <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">

   <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">

 

   <!-- Main styles for this application -->

   <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">

   <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_editor.min.css' rel='stylesheet' type='text/css' />

   <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_style.min.css' rel='stylesheet' type='text/css' />

    <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">



   <!-- Styles required by this views -->



   <style>

  .modal-content {

       color: black;

       width: 120%;

    }

</style>

 

 </head>



 

 <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">

   <div class="app-body"> 

     <!-- Main content -->

     <main class="main mainbg">

       <!-- Breadcrumb -->

       <ol class="breadcrumb breadcrumbbg">

         <li class="breadcrumb-item">Home</li>

         <li class="breadcrumb-item">Admin</li>

         <li class="breadcrumb-item active">Holidays</li>

         <!-- Breadcrumb Menu-->

       </ol>

 

       <div class="container-fluid dashboradbg">

         <div class="animated fadeIn">

          <div class="row">

               <div class="col-sm-2">

                <?php if($role == 1 || $role == 3|| $role == 4|| $role == 5){ ?>

               <button type="button" class="btn green" id="leave_btn" data-toggle="modal" data-target="#modalleave"><i class="fa fa-plus"></i> Add Holiday</button><?php } ?>

              </div>

            </div>

            <p id="leave_errors_type_del" style="color:red;"></p>

            <div class="panel panel-default">

              <div class="panel-heading">Employee Holiday</div>

              <div class="panel-body">

                

                <table class="table table-bordered myTable">

                  <thead>

                    <tr>

                      <th scope="col">Holiday Name</th>

                      <th scope="col">Holiday Date</th>

                      <th scope="col">Created Date</th>

                      <?php if($role == 1 || $role == 3|| $role == 4|| $role == 5){ ?>

                      <th scope="col">Action</th><?php } ?>

                    </tr>

                  </thead>

                  <tbody id="tdetails">

                    <?php foreach($holiday_list as $holiday_list){

                    date_default_timezone_set('Asia/Kolkata'); ?>

                      <tr>

                      <td><?php echo $holiday_list->name;?></td>

                       <td><?php echo date('d-m-Y',$holiday_list->holiday_date);?></td>

                      <td><?php echo date('d-m-Y',$holiday_list->created_date);?></td>

                      <?php if($role == 1 || $role == 3|| $role == 4|| $role == 5){ ?>

                      <td><i class="fa green fa-edit" aria-hidden="true"  onclick = "getleavetype('<?php echo $holiday_list->hol_list_id;?>')"></i><i class="fa  red fa-trash red" aria-hidden="true" onclick = "delleavetype('<?php echo $holiday_list->hol_list_id;?>')"></i></td>

                        <?php }} ?>

                    </tr>

                  </tbody>

                  </table>

              </div>

            </div>

           </div>

         </div>

        </main>

       </div>

<?php if($role == 1 || $role == 3|| $role == 4|| $role == 5){ ?>

<!-- Central Modal Small -->
<div class="modal fade" id="modalleave" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">

  <!-- Change class .modal-sm to change the size of the modal -->
  <div class="modal-dialog modal-lg" role="document">


    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title w-100" id="myModalLabel">Add Holiday</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          <input type="hidden" id="holiday_id">
        </button>
      </div>
      <div class="modal-body">
        <div class="panel panel-primary">
                        <div class="Inventory">
                           <div class="row ">
                              <div class="table-responsive">
                                <form id="form_dt">
                                 <table class="table table-bordered exmp" id="example">
                                    <thead>
                                       <tr>
                                          <th style="width: 11px;">Name</th>
                                          <th style="width: 11px;">Date</th>
                                          <th style="width: 31px;" class="action">Action</th>
                                       </tr>
                                    </thead>
                                    <tbody>

                                    	<tr>

                                    	<td><div class = "col-md-7"><input type ="text" class="form-control hol_name" name="hol_name" placeholder="Holiday Name"></div></td>

                                    	<td><div class = "col-md-7"><input class="form-control datepicker holiday_date" name="holiday_date" placeholder="Holiday Date"></div></td>

                                      <td><div class = "col-md-3 plus">
                                            <button type = "button"><i style="font-size:27px; color:blue;" class="fa" onclick="moreholiday()">&#xf055;</i></button>

                                          </div></td>

                                    </tr>
                                       
                                    </tbody>
                                 </table>
                               </form>
                              </div>
                           </div>
                        </div>
                        <div class="button_rows_order"></div>
                     </div>
      </div>
      <div class="modal-footer">
        <p class="display_mssg" id="display_mssg" style="color:red;"></p>
        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-sm common_add" id="holiday_list">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!-- Central Modal Small -->

<?php } ?>


   <!-- Bootstrap and necessary plugins -->

   <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>

   <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>

   <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>

   <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>

 

   <!-- Plugins and scripts required by all views -->

   <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>

   <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script> 

   <script src="<?php echo base_url();?>js/app.js"></script>

   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

 

   <!-- Plugins and scripts required by this views -->

 

   <!-- Custom scripts required by this view -->

   <script src="<?php echo base_url();?>js/views/main.js"></script>

   <script src="<?php echo base_url();?>js/career.js"></script>



   <script>



$(document).ready(function() {

       $('.myTable').DataTable({

        "aaSorting": []
        
       });

            $('.datepicker').datepicker({

               dateFormat: 'dd-mm-yy'

           });

      });

      $('#mymodal').on('hidden.bs.modal', function () {

          location.reload();
      })



$('#modalleave').on('hidden.bs.modal', function () {

 location.reload();

});







  function delleavetype(id){

      if(confirm("Are you sure want to delete!")){

  $.ajax({

    type:"POST",

      url:"<?php echo base_url();?>HolidayList/holiday_del",

   data:{

      "id":id,

  },

  success:function(response){

    console.log(response);

   $("#leave_errors_type_del").html("Holiday Successfully Deleted");

  setTimeout(function(){

    location.reload();

  },3000);

  }

  });

  }

}



function getleavetype(id){

  $.ajax({

    type:"POST",

      url:"<?php echo base_url();?>HolidayList/get_holiday",

   data:{

      "id":id,

  },

        dataType:'json',

  success:function(response){

    console.log(response);

  $.each(response,function(key,value){

    var new_date = new Date(value.holiday_date * 1000);


    var year = new_date.getFullYear();

    var month = new_date.getMonth() + 1;

    var day = new_date.getDate();

    $("#holiday_id").val(value.hol_list_id);

    $(".hol_name").val(value.name);

    $(".holiday_date").val(day+'-'+month+'-'+year);

    $("#example").find('tr').find("td:last").remove();

    $("#example").find('tr').find("th:last").remove();

    $("#leave_btn").html('Edit Leavetype');

    $("#leave_ins_btn").html('Update');

    $("#leave_ins_btn").val('Update');

    $("#modalleave").modal('show');

  });

  }

  });

}

var button_index = 0;


function moreholiday(){

     button_index ++;
   
   
   
      var row = button_index + 2;
   
   
   
     $('#example').append('<tr class="dec'+button_index+'"><td><div class="form-group col-md-7"><input type ="text" class="form-control hol_name" name="hol_name" placeholder="Holiday Name"></div></td><td><div class="form-group col-md-7"><input type ="hoiday_date" class="form-control datepicker holiday_date" name="holiday_date" placeholder="Holiday Date"></div></td><td><div class="col-md-2"><p><a href="#"><button type= "button"><i style="font-size:24px; color:red" class="fa" onclick="removerow2('+button_index+')">&#xf014;</i></button></a></p></div></td></tr>');

      $('.datepicker').datepicker({

               dateFormat: 'dd-mm-yy'

           });

   }

function removerow2(index){
   
   
   
     console.log(index);
   
   
   
     $('.dec'+index).remove();
   
   
   
   }



</script>

 </body>

 </html>