<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <link href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
      <!-- Styles required by this views -->
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Dashboard</li>
               <li class="breadcrumb-item active">Task_Entry</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Entry Task</div>
                           <div class="panel-body" style="overflow: hidden;">
                              <form name="MyForm" id="form_dt" autocomplete="off">
                                 <div class="row">
                                    <?php if(ISSET($edit_records) && !empty($edit_records)) {

                                       foreach($edit_records as $records){
                                          ?>
                                  <input type="hidden" id="id" class="id" value="<?php echo $id;?>">

                                  <input type="hidden" id="role" class="role" value="<?php echo $role;?>">

                                    <div class="form-group col-md-3">
                                       <label for="ProjectName">Employee Name</label>
                                       <select type="select" class="form-control emp_name_val" id="name_filter">

                                          <option value="<?php echo $records->employee_ID;?>"><?php echo $records->first_name.' '.$records->last_name; ?></option>
                                          <?php foreach($employee as $emp){

                                          if($emp->uniqueID != $records->employee_ID) {?>
                                          <option value="<?php echo $emp->uniqueID; ?>"><?php echo $emp->first_name.' '.$emp->last_name; ?></option>
                                          <?php } }?>
                                       </select>
                                    </div>
                                    <div class="form-group col-md-3">
                                       <label for="ProjectName">Project Name</label>
                                       <select type="select" class="form-control project_name_val" id="name_filter">

                                          <option value="<?php echo $records->project_code;?>"><?php echo $records->name; ?></option>
                                          <?php foreach($project_name as $val){ 

                                          if($val->project_code != $records->project_code) {?>?>
                                          <option value="<?php echo $val->project_code; ?>"><?php echo $val->name; ?>(<?php echo $val->project_code; ?>)</option>
                                          <?php } }?>
                                       </select>
                                    </div>
                                    <div class="form-group col-md-5">
                                       <label for="email">Task Assigned</label>
                                       <textarea id="form7" class="md-textarea form-control task_assigned" rows="3" placeholder="Enter Task Assigned" ><?php echo $records->task_assigned;?></textarea>
                                    </div>
                                    
                                    <div class="form-group col-md-2">
                                       <label for="email">Week Start Date</label>
                                       <input class="form-control datepicker week_start_date" autocomplete="off" name ="task_date" placeholder="Task Date" onkeydown="return false;" value="<?php echo date('d-m-Y',$records->week_start_date);?>">
                                    </div>
                                    <div class="form-group col-md-2">
                                       <label for="email">Week End Date</label>
                                       <input class="form-control datepicker week_end_date" autocomplete="off" name ="task_date" placeholder="Task Date" onkeydown="return false;" value="<?php echo date('d-m-Y',$records->week_end_date);?>">
                                    </div>
                                    <?php if($role == 0){ ?>
                                    <div class="form-group col-md-2">
                                       <label for="email">Task Start Date</label>
                                       <input class="form-control datepicker task_start_date" autocomplete="off" name ="task_date" placeholder="Task Start Date" onkeydown="return false;" value="<?php echo ($records->task_start_date == "N/A") ? '':date('d-m-Y',$records->task_start_date);?>" >
                                    </div>
                                    <div class="form-group col-md-2">
                                       <label for="email">Task End Date</label>
                                       <input class="form-control datepicker task_end_date" autocomplete="off" name ="task_date" placeholder="Task End Date" onkeydown="return false;" value="<?php echo ($records->task_end_date == "N/A") ? '' : date('d-m-Y',$records->task_end_date);?>">
                                    </div>
                                    <div class="form-group col-md-11">
                                       <label for="email">Task Complete Description</label>
                                       <textarea class="form-control" id="editors" placeholder="Enter message" name="editor1" id="editor1" required><?php echo $records->task_complete_desc; ?></textarea>
                                    </div>
                                    <div class="form-group col-md-2">
                                       <label for="email">Hours to Complete Task</label>
                                       <input class="form-control hours_worked" type="number" autocomplete="off" name ="hours_worked" placeholder="hours to be worked" value = "<?php echo $records->hours_worked;?>">
                                    </div>
                                    <div class="form-group col-md-2">
                                       <label for="email">Status</label>
                                       <select type="select" class="form-control status">
                                          <option value="<?php echo $records->status;?>"><?php echo ($records->status == 0 ? 'Completed' : ($records->status == 1 ? 'In-Progress' : ($records->status == 2 ? 'In-Hold' :'Not Started'))); ?></option>
                                          <?php if($records->status == 1){ echo '<option value="0">Completed</option><option value="2">In-Hold</option>';
                                          } else if($records->status == 0){ echo '<option value="1">In-Progress</option><option value="2">In-Hold</option>';
                                          } else if($records->status == 2){ echo '<option value="0">Completed</option><option value="2">In-Hold</option>';
                                          }else if($records->status == 3){ echo '<option value="0">Completed</option><option value="1">In-Progress</option><option value="2">In-Hold</option>'?>                                                                             
                                          <?php } ?>
                                       </select>
                                    </div>
                                    <?php } ?>
                                    <div class="form-group col-md-5">
                                       <label for="email">Comments</label>
                                       <textarea id="form7" class="md-textarea form-control comments" rows="3" placeholder="Enter Comments"><?php echo $records->comments;?></textarea>
                                    </div>
                                 </div>
                                 <?php } }?>
                              </form>
                           </div>
                        </div>
                     </div>
                     <div class="form-group col-md-12" style="clear: both;">
                        <input type="button" class="btn btn-success common_add" id="work_tracker" value="Update Request"> <input type="button" class="btn btn-success" id="reset_opt" value="Reset">&nbsp<input type="button" class="btn btn-success" id="reset_opt" value="Back" onclick="back()"> 
                        <p id="ins_errors" style="color:red!important; font-size:18px;"></p>
                     </div>
                  </div>
               </div>
            </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </main>
      </div>
      <div class="modal fade" id="myModal" role="dialog" style="width:100%;">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Message</h4>
               </div>
               <div class="modal-body">
                  <h4 id="view_mssg_res"></h4>
                  <p id="view_mssg"></p>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <!-- Leaf Lite main scripts -->
      <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script> 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
      <script>
         var editor = CKEDITOR.replace( 'editor1' );
         
         $(document).ready( function () {

            ($(".role").val() == 0) ? $(".emp_name_val,.project_name_val,.task_assigned,.week_start_date,.week_end_date").attr('disabled','disabled') : "";


         
         var holidays = getholiday_list();
         
         $('.datepicker').datepicker({
         
         format: 'dd-mm-yy',
         
         beforeShowDay: $.datepicker.noWeekends,
         
         firstDay:1,
         
         beforeShowDay: function (date) {
         
         var datestring = jQuery.datepicker.formatDate('yy-mm-dd', date);
         
         var monday = new Date();
         
         monday.setHours(0,0,0,0);
         
         monday.setDate(monday.getDate() + 1 - (monday.getDay() || 7));
         
         var saturday = new Date(monday);
         
         saturday.setDate(monday.getDate() + 5);
         
         return [date >= monday && date < saturday && holidays.indexOf(datestring) == -1];
         }
         });
         
         });
         
         function back(){
         
         
         window.location.href = window.location.origin + "/login/"+"work_tracker";


         }
         
         function CKupdate(){
         CKEDITOR.instances.editors.setData('');
         }
         
         
         function getholiday_list(){
         
         var jqXHr =  $.ajax({
         
         type:"POST",
         
         url:"<?php echo base_url(); ?>Timesheet/holiday_list",
         
         data:{},
         
         dataType:'json',
         
         async: false,
         
         success:function(response){
         
         return response;
         
         }
         
         
         });
         
         return jqXHr.responseText;
         }
         
      </script>
   </body>
</html>