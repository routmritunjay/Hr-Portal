<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <!-- Icons -->
      <link href="<?php echo base_url(); ?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url(); ?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url(); ?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/css/bootstrap-multiselect.css">
      <!-- Styles required by this views -->
      <style>
         .modal-content {
         color: black;
         width: 120%;
         }
         .table {
         width: 100%;
         display:block;
         overflow: auto;
         } 
      </style>
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <!-- Main content -->
         <main class="main mainbg">
            <!-- Breadcrumb -->
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Admin</li>
               <li class="breadcrumb-item active">Employee Leaves</li>
               <!-- Breadcrumb Menu-->
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <?php if($leave_id == "") {?>
                  <div class="row">
                     <div class="col-md-12">
                        <p id="filteration_err" style="color:red;"></p>
                        <div class="panel panel-default">
                           <div class="panel-heading">Leave Filter</div>
                           <p></p>
                           <div class="col-sm-12 col-md-12" style="display: inline-flex;">
                              <div class="col-sm-3">
                                 <input type="hidden" id="roles" value="<?php echo $role;?>">
                                 <select name="job_role" class="multiselect-ui name_filter form-control" id="name_filter"  multiple="multiple">
                                    <?php foreach($all_employee as $all_emp){ ?>
                                    <option value="<?php echo $all_emp->email; ?>"><?php echo $all_emp->first_name; ?><?php echo $all_emp->last_name; ?></option>
                                    <?php } ?>
                                 </select>
                              </div>
                              <div class="col-sm-3">
                                 <select class="form-control ltype_multiselect-ui leave_type" id="leave_type" name= "leave_type"  multiple="multiple">
                                    <?php foreach($leave_type as $leave_type){?>
                                    <option value="<?php echo $leave_type->leave_unique_id; ?>"><?php echo $leave_type->leave_type; ?></option>
                                    <?php } ?>
                                 </select>
                              </div>
                              <div class="col-sm-2" autocomplete="off">
                                 <input type="text" class="form-control datepicker to_date" name ="to_date" id ="to_date" placeholder="Start date">
                              </div>
                              <div class="col-sm-2" autocomplete="off">
                                 <input type="text" class="form-control datepicker to_date" name ="end_date" id="end_date" placeholder="End date">
                              </div>
                              <div class="col-sm-3">
                                 <button type="button" class="btn green" id="leave_filter_options"><i style="font-size:17px" class="fa">&#xf0b0;</i></button>
                                 <button type="button" class="btn green" id="reset_opt"><i style="font-size:17px" class="fa">&#xf021;</i></button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <?php } ?>
                  <div class="row">
                  </div>
                  <p id="ins_errors" style="color:red!important; font-size:19px;"></p>
                  <div class="panel panel-default">
                     <input type="hidden" id="role_default" class="role_default" value="<?php echo $role; ?>">
                     <div class="panel-heading">Applied Leave</div>
                     <div class="panel-body">
                        <table class="table table-bordered myTable">
                           <thead>
                              <tr>
                                 <th scope="col">Name</th>
                                 <th scope="col">Leave-Type</th>
                                 <th scope="col">Leave-Pattern</th>
                                 <th scope="col">Start-Date</th>
                                 <th scope="col">End-Date</th>
                                 <th scope="col">No-of-Days</th>
                                 <th scope="col">Message</th>
                                 <th scope="col">Message</th>
                                 <th scope="col">Applied-Date</th>
                                 <th scope="col">Manager-Approval</th>
                                 <th scope="col">CEO-Approval</th>
                                 <th scope="col">Manager-Comments</th>
                                 <th scope="col">CEO-Comments</th>
                              </tr>
                           </thead>
                           <tbody id="tdetails">
                              <?php foreach($leavedetails as $leavedetails){ ?>
                              <tr>
                                 <td><?php echo $leavedetails->applicant_name;?></td>
                                 <td><?php echo $leavedetails->leave_type;?></td>
                                 <?php if($leavedetails->leave_pattern != "") { ?>
                                 <td><?php echo $leavedetails->leave_pattern;?></td>
                                 <?php }else{ ?>
                                 <td>NA</td>
                                 <?php } ?>
                                 <?php if($leavedetails->leave_from_date != "" && $leavedetails->leave_to_date != "" && $leavedetails->total_days != ""){ ?>
                                 <td><?php echo $leavedetails->leave_from_date;?></td>
                                 <td><?php echo $leavedetails->leave_to_date;?></td>
                                 <td><?php echo $leavedetails->total_days;?></td>
                                 <?php }else{ ?>
                                 <td>NA</td>
                                 <td>NA</td>
                                 <td>NA</td>
                                 <?php } ?>
                                 <td><button type="button" class="btn btn-default" onclick = getleavemssgdetails('<?php echo $leavedetails->leave_id;?>','<?php echo $leavedetails->applicant_email;?>');>View</button></td>
                                 <td><?php echo $leavedetails->message; ?></td>
                                 <td><?php echo $leavedetails->appiled_date;?></td>


                                 <td><?php echo ($leavedetails->manager_approval == 'pending' ? '<a href = "#" class="link2 green" onclick = comment_update_func('.$leave_value = str_replace(' ','',$leavedetails->leave_unique_id).",'".$leavedetails->leave_id."','".$leavedetails->applicant_email."','".$role."',".'"approve"'.",".'"manager"'.')><i class="fa">&#xf00c;</i></a><a href = "#" class="link2 red" onclick = comment_update_func('.$leave_value = str_replace(' ','',$leavedetails->leave_unique_id).",'".$leavedetails->leave_id."','".$leavedetails->applicant_email."','".$role."',".'"reject"'.",".'"manager"'.')><i class="fa">&#xf00d;</i></a>' : ($leavedetails->manager_approval == 'rejected' ? '<a href="#" class="red"><i class="fa">&#xf00d;</i></a>':'<a href="#"  class="green"><i class="fa">&#xf00c;</i></a>'))?></td>
                                 <td><?php echo ($leavedetails->ceo_approval == 'pending' ? '<a href = "#" class="link4 green" onclick = statusupdate('.$leave_value = str_replace(' ','',$leavedetails->leave_unique_id).",'".$leavedetails->leave_id."','".$leavedetails->applicant_email."','".$role."',".'"approve"'.",".'"ceo"'.')><i class="fa">&#xf00c;</i></a><a href = "#" class="link4 red" onclick = statusupdate('.$leave_value = str_replace(' ','',$leavedetails->leave_unique_id).",'".$leavedetails->leave_id."','".$leavedetails->applicant_email."','".$role."',".'"reject"'.",".'"ceo"'.')><i class="fa">&#xf00d;</i>' : ($leavedetails->ceo_approval == 'rejected' ? '<a href="#" class="red"><i class="fa">&#xf00d;</i></a>': ($leavedetails->ceo_approval == 'approved' ? '<a href="#" class="green"><i class="fa">&#xf00c;</i></a>' : '')))?></td>
                                 <td><?php echo ($leavedetails->manger_comments) == ''  ? 'N/A' : $leavedetails->manger_comments?></td>
                                 <td><?php echo ($leavedetails->ceo_comments) == ''  ? 'N/A' : $leavedetails->ceo_comments?></td>    
                              </tr>
                              <?php } ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </main>
      </div>
      
      <div id="modalleave" class="modal fade" role="dialog">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Leave Type</h4>
               </div>
               <div class="modal-body">
                  <form name="MyForm">
                     <div class="form-group">
                        <label for="pname">Leave Type:</label>
                        <input type="text" class="form-control" id="leave_type_ins" name="leave_type_ins" placeholder="Enter Leave Type">
                     </div>
                     <div class="form-group">
                        <p id="leave_errors_type_ins" style="color:red;"></p>
                        <button type="button" class="btn btn-success" id="leave_ins_btn" value="submit">Add Leavetype</button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <div class="modal fade" id="myModal" role="dialog" style="width:100%;">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <h4 class="modal-title">Message</h4>
               </div>
               <div class="modal-body">
                  <h4 id="view_mssg_res"></h4>
                  <p id="view_mssg"></p>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <!-- Leaf Lite main scripts -->
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/js/bootstrap-multiselect.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="<?php echo base_url();?>js/views/.main.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
   	<script src="<?php echo base_url();?>assests/ajaxjs/leave_ajax.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>  
      <script>
         $(document).ready(function() {

          

         $(".leaveId").hide();
              var dataTable = $('.myTable').DataTable({

                "aaSorting": [],

               dom: 'Bfrtip',
                buttons: [
                     {
                   extend: 'pdf',
                   footer: true,
                   exportOptions: {
                      columns: [ 1,2,3,4,5,6,8,9,12,13]
                   }},
                    {
                   extend: 'excel',
                   footer: true,
                   exportOptions: {
                      columns: [1,2,3,4,5,6,8,9,12,13]
                   }}],
              	columnDefs: [
                 {
                     "targets": [7],
                     "visible": false,
               }],
            initComplete: function(){

               $(".dt-buttons").append('<button type="button" class="btn btn-default dt-button" id="employee_excel_data" onclick="employee_excel_data();">Payroll Excel</button>'); 

               $('#employee_excel_data').css({

                          'margin-left': '91px',

                          'margin-top': '-29px'

                   });  

               },  
                 "bAutoWidth": false
             });

            $("#employee_excel_data").css("display","none");
         
           $(".button_edit").click(function(){
            $("#myModal").modal('show');
            });
            var role = $("#role_default").val();
            if(role == 2){
              $(".link1,.link3,.link4").prop('onclick', null);
             }else if(role == 3 || role == 5 || role == 6){
               $(".link2,.link3,.link4").prop('onclick', null);
             }else if(role == 7){
               $(".link1,.link3").prop('onclick', null);
             }
            });
         
         
         $(document).ready(function(){
            $('.datepicker').datepicker({
               dateFormat: 'yy-mm-dd',
               beforeShowDay: $.datepicker.noWeekends
           });
          });
         
      

        function statusupdate(leave_id,id,email,role,status,update_type){

          	var ajaxjs = $.ajax({

		         type:"POST",
		         url:"<?php echo base_url(); ?>Leave/checkmanagerapproval",
		         data:{"id":id},
		         dataType:'json'
		     });

          	ajaxjs.done(function(response){

          		if(response.length != 0){

          			var err = "";

          			if(response.manager_approval == "pending" && $("#role_default").val() != 2){

          				err = "false";

          				show_mssg = "Updation Failed.Waiting for Manager Approval";

          				$("#ins_errors").html("Manager approval is pending.Please update the status!").css("color","red");

          			}else{

          				err = "true";

          			}

          			if(err == "true"){

          				comment_update_func(leave_id,id,email,role,status,update_type);

          			}

          		}

          	});

          	 ajaxresult.fail(function(jqXHR, textStatus, errorThrown){

               $("#ins_errors").html(textStatus + ': ' + errorThrown).css('color','red');

    		});

          	}
                   
        
         
         $('#mymodal').on('hidden.bs.modal', function () {
         location.reload();
         })
         
         $('#modalleave').on('hidden.bs.modal', function () {
         location.reload();
         })
         
         

         
      </script>
   </body>
</html>