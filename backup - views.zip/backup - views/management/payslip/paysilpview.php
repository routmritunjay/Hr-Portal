<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_editor.min.css' rel='stylesheet' type='text/css' />
      <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_style.min.css' rel='stylesheet' type='text/css' />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <!-- Styles required by this views -->
      <style>
         select:invalid { color: gray; }
      </style>
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Dashboard</li>
               <li class="breadcrumb-item active">Payslip</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  
                  <p id="ins_errors" style="color:red; font-size:15px;"></p>
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Payslip - Filter</div>
                           <p id="filteration_err" style="color:red;"></p>
                           <div class="col-sm-12 col-md-12" style="display: inline-flex;">
                              <div class="col-sm-5">
                                 <select name="job_role" class="form-control" id="emp_id">
                                    <option value="" disabled selected hidden>Select An Employee</option>
                                    <?php foreach($all_emp as $all_emp){ ?>
                                    <option value="<?php echo $all_emp->uniqueID; ?>"><?php echo $all_emp->first_name; ?> <?php echo $all_emp->last_name; ?></option>
                                    <?php } ?>
                                 </select>
                              </div>
                              <div class="col-md-3">
                                 
                    <input name="startDate" class="form-control date-picker" id="fil_month"  placeholder ="Select Month" />  

                              </div>
                              <div class="col-md-3">
                                 <button type="button" class="btn green" id="filter_options" onclick="payslip_filter('management')"><i style="font-size:17px" class="fa">&#xf0b0;</i></button>
                                 <button type="button" class="btn green" id="reset_opt"><i style="font-size:17px" class="fa">&#xf021;</i></button>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="panel panel-default">
                     <div class="panel-heading">Payslip List</div>
                     <div class="panel-body">
                        <table class="table table-bordered myTable" id="tdetails">
                           <thead>
                              <tr>
                                 <th scope="col">First Name</th>
                                 <th scope="col">Last Name</th>
                                 <th scope="col">Month</th>
                                 <th scope="col">Payslips</th>
                                 <th scope="col">Created Date</th>
                                 <?php if($role == 1 || $role == 7 || $role == 4){ ?>
                                 <th scope="col">Action</th>
                                 <?php } ?>
                              </tr>
                           </thead>
                           <tbody id="tbdydtls">
                              <?php foreach($payslip_details as $payslip_details){ ?>
                              <tr>
                                 <td><?php echo $payslip_details->first_name; ?></td>
                                 <td><?php echo $payslip_details->last_name; ?></td>
                                 <td><?php echo date("F", mktime(0, 0, 0, $payslip_details->payslip_month, 10));?>-<?php echo $payslip_details->payslip_year;?></td>
                                 <td><a href='<?php echo $payslip_details->uploaded_payslip;?>' target='_blank' height='70'>View</a></td>
                                 <td><?php echo $payslip_details->update_date; ?></td>
                                 <?php if($role == 1 || $role == 7 || $role == 4){ ?>
                                 <td><i class="fa fa-trash red" aria-hidden="true" onclick="deletepayslip('<?php echo $payslip_details->payslip_id; ?>')"></i></td>
                                 <?php } ?>
                              </tr>
                              <?php }?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </main>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script> 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="<?php echo base_url();?>js/views/main.js"></script>
      <script src="<?php echo base_url();?>assests/ajaxjs/payslip_filter_ajax.js"></script>
      <script type="text/javascript">
         $(document).ready(function() {

             $('.myTable').DataTable({

              "aaSorting": []
              
            });

             $('.date-picker').datepicker( {
                    changeMonth: true,
                    changeYear: true,
                    showButtonPanel: true,
                    dateFormat: 'MM yy',
                    onClose: function(dateText, inst) { 
                        var month = $("#ui-datepicker-div .ui-datepicker-month :selected").val();
                        var year = $("#ui-datepicker-div .ui-datepicker-year :selected").val();
                        $(this).datepicker('setDate', new Date(year, month, 1));
                    }
                });

            });

         function deletepayslip(id){
          
          $("#ins_errors").empty();

          if(confirm("Are you sure want to delete!")){

              $.ajax({
                type:"POST",
                url:"<?php echo base_url(); ?>Payslips/payslip_del",
                data:{"id":id,},
              success:function(response){
                console.log(response);
               $("#ins_errors").html("Payslip successfully deleted");
                setTimeout(function(){
                  location.reload();
                },3000);
                }
                });
                }
           }
         
      </script>
   </body>
</html>