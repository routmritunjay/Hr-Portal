 <!DOCTYPE html>
 <html lang="en">
 <head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
   
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
   <meta name="author" content="Łukasz Holeczek">
   <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
   <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
   <title>Intelexsystemsinc.com</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
   <!-- Icons -->

   <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
   <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
     
   <!-- Main styles for this application -->
   <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />
   <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
   <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
   <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
   <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
   <!-- Styles required by this views -->
 </head>
 
 
 <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
   <div class="app-body">
     <main class="main mainbg">
       <ol class="breadcrumb breadcrumbbg">
         <li class="breadcrumb-item">Home</li>
         <li class="breadcrumb-item">Dashboard</li>
         <li class="breadcrumb-item active">Employee Timesheet</li>
       </ol>
 
       <div class="container-fluid dashboradbg">
        <div class="animated fadeIn">
          <div class="row">
        <div class="col-sm-12">
          <div class="panel panel-default">
            <div class="panel-heading">Timesheet - Filter</div>
            <p id="filteration_err" style="color:red !important;"></p>
              <div class="col-sm-12 col-md-12" style="display: inline-flex;">
                <div class="col-sm-3">
                  <input type="hidden" class="role" id="role" value = "<?php echo $role; ?>">
                  <select name="job_role" class="form-control multiselect-ui" id="name_filter"  multiple="multiple">
                    <?php foreach($all_employee as $all_emp){ ?>
                     <option value="<?php echo $all_emp->uniqueID; ?>"><?php echo $all_emp->first_name; ?><?php echo $all_emp->last_name; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                  <div class="col-md-3">
                      <input class="form-control datepicker task_date" autocomplete="off" name ="task_date" placeholder="Start task Date">
                  </div>
                  <div class="col-md-3">
                      <input class="form-control datepicker end_task_date" autocomplete="off" name ="task_date" placeholder="End task Date">
                  </div>
                 <div class="col-md-3">
                   <button type="button" class="btn green" id="timesheet_filter_options"><i style="font-size:17px" class="fa">&#xf0b0;</i></button>
                    <button type="button" class="btn green" id="reset_opt"><i style="font-size:17px" class="fa">&#xf021;</i></button>
                 </div>
          </div>
        </div>
        <div class="row">
              <div class="col-sm-2 wrkng_prtl" style="color:green;">
            <h5>Total Time Spent:-</h5>
            </div>  
            <div class="col-sm-1 wrkng_prtl">
              <p id="ttl_hrs"></p>
            </div>
            <?php if($role == 7){ ?>
             <div class="checkbox">
                     <label><input type="checkbox" id="select_all" />Select All</label>
                   </div>
                   <?php } ?>
              </div>
        </div>
          </div>
          <div class="row">
            <div class="col-md-12">
            <div class="panel panel-default">
              <div class="panel-heading">Employee Timesheet Records</div>
              <div class="panel-body">
                <table class="table table-bordered myTable">
                   <thead>
                    <tr>
                      <th scope="col">Employee-Name</th>
                      <th scope="col" nowrap>Task-Date</th>
                      <th scope="col">Project-Name</th>
                       <th scope="col" class="desc">Task-Description</th>
                      <th scope="col">Task-Description</th>
                      <th scope="col" nowrap>Time-Spent(hrs)</th>
                      <th scope="col">Status</th>
                      <th scope="col">Updated-on</th>
                      <th scope="col" nowrap>Approval Status</th>
                      <th scope="col" nowrap>Approval Status</th>
                    </tr>
                  </thead>
                  <tbody id="tdetails">
                    <?php
                    foreach($task_summary as $task_summary){ ?>
                      <tr>
                     <td><?php echo $task_summary['first_name']; ?><?php echo $task_summary['last_name']; ?></td>
                      <td><?php echo date('d-m-Y',$task_summary['task_date']); ?></td>
                      <td><?php echo ($task_summary['name'] != "") ?$task_summary['name'] : $task_summary['project_name']; ?></td>
                      <td><?php echo $task_summary['task_description']; ?></td>
                      <td><button type="button" class="btn btn-default" onclick = getmssgdetails('<?php echo $task_summary['task_id'];?>');>View Description</button></td>
                      <td><?php echo $task_summary['total_time_spent']; ?></td>
                      <td><?php echo $task_summary['status']; ?></td>
                      <td><?php echo $task_summary['updated_on']; ?></td>
                      <td><?php echo ($task_summary['approval_status'] == 'Approved' ?'<a href="#" class="green"><i class="fa">&#xf00c;</i></a>':($task_summary['approval_status'] == 'Reject' ?'<a href="#" class="red"><i class="fa">&#xf00d;</i></a>' : '<i class="fa fa-clock-o" aria-hidden="true">'))?></td>
                        <td><?php echo ($task_summary['approval_status'] == 'Approved' ?'Approved':($task_summary['approval_status'] == 'Reject' ?'Rejected' : 'Pending'))?></td>
                  </tr>
                      <?php } ?>
                  </tbody>
                  <tfoot id="tfoot"><tr><td></td><td></td><td></td><td>Total Time spent</td><td></td><td id="tspent"><?php echo $total_time_spent; ?></td></tr></tfoot>
                  </table>
              </div>
            </div>
           </div>
           </div>
            </div>
            </div>
          </div>
        </div>
             </div>
           </div>
         </div>
       </div>
     </main>
   </div>

   <div class="modal fade" id="myModalx" role="dialog" style="width:100%;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Task Description</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
         <div class="modal-body">
          <p id="view_mssg"></p>
       </div>  
       <div class="modal-footer">
      </div>   
    </div>
  </div>
</div>

<footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
   <!-- Bootstrap and necessary plugins -->
   <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
   <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
   <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
 
   <!-- Plugins and scripts required by all views -->
   <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>

   <!-- Leaf Lite main scripts -->
 
   <script src="<?php echo base_url();?>js/app.js"></script>
 
   <!-- Plugins and scripts required by this views -->
 
   <!-- Custom scripts required by this view -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script> 
  <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
<script>
$(document).ready( function () {

  $("#tfoot").hide();

  $(".approve_reject_btn").hide();

  $(".desc").hide();

  var roles = 3;

   var dataTable = $('.myTable').DataTable({


    "fnRowCallback": function( nRow, aData, iDisplayIndex ) {


         if(aData[2] == "Leave" || aData[2] == "holiday"){

                    $(nRow).css('background-color', 'grey');

                  }

        },
      dom: 'lBfrtip',
        buttons: [
            {
          extend: 'pdf',
          footer: true,
          exportOptions: {
             columns: [ 0,1,2,3,5,6,7,9]
          }},
           {
          extend: 'excel',
          footer: true,
          exportOptions: {
             columns: [ 0,1,2,3,5,6,7,9]
          }}],
  });

   dataTable.columns( [3,9] ).visible( false);

   $('.datepicker').datepicker({

    format: 'dd-mm-yyyy',

 });
});



 function getmssgdetails(id,name){
   $.ajax({
  type:"POST",
  url:"<?php echo base_url(); ?>Leave/getmssgdetails",
  data:{
    "id":id,
    "name":name
 },
  dataType:'json',
success:function(response){
  console.log(response);
  $.each(response,function(key,value){
    $("#view_mssg_res").html(value.restricted_holiday);
    var mssg = value.message;
    var value = mssg.replace(/(<p[^>]+?>|<p>|<\/p>)/img, "");
    $("#view_mssg").html(value);
  });
  $("#myModal").modal('show');
}
});
}


function CKupdate(){
  CKEDITOR.instances.editors.setData('');
}

function task_view(project_id){
  window.location.href="<?php echo base_url(); ?>Employee_project/taskview?pro_id="+project_id;
}

function getmssgdetails(id,name){
   $.ajax({
  type:"POST",
  url:"<?php echo base_url(); ?>Timesheet/getmssgdetails",
  data:{
    "id":id
 },
  dataType:'json',
success:function(response){
  console.log(response);
  $.each(response,function(key,value){
    var mssg = value.task_description;
    $("#view_mssg").html(mssg);
  });
  $("#myModalx").modal('show');
}
});
}


$("#reset_opt").click(function(){
location.reload();
});



</script>
 </body>
 </html>