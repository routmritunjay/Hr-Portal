<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_editor.min.css' rel='stylesheet' type='text/css' />
      <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_style.min.css' rel='stylesheet' type='text/css' />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
      <link rel ="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.5/css/bootstrap-select.min.css">
      <!-- Styles required by this views -->
      <style type="text/css">
         .removebttn{margin-top: 28px;}
      </style>
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Dashboard</li>
               <li class="breadcrumb-item active">Events</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Add An Event</div>
                           <div class="panel-body" style="overflow: hidden;">
                              <form name="MyForm" autocomplete="off" id="form_dt">
                                 <input type="hidden" id="res_date">
                                 <input type="hidden" id="btn_cntr_val">
                                 <input type="hidden" id="id" name="emp_id" class="id">
                                 <p id="leave_type_errors" style="color:red!important; font-size:17px;"></p>
                                 <div class="row">
                                    <div class="form-group col-md-3">
                                       <label for="email">Title</label>
                                       <select type="select" name="event_title" class="form-control event_title">
                                       	<option value="none">Select An Title</option>
                                       	<?php foreach ($title as $key => $value) { ?>
                                       		<option value="<?php echo $value->id; ?>"><?php echo $value->type; ?></option>
                                       	<?php } ?>
                                       </select>
                                    </div>
                                    <div class="form-group col-md-3 fromdate">
                                       <label for="email">Date</label>
                                       <input class="form-control datepicker event_date" name ="date" placeholder="Enter Date">
                                    </div>
                                    <div class="form-group col-md-3 fromdate"><label for="email">Time</label><input class="form-control timepicker event_time" name ="event_time" placeholder="Start date"></div>
                                    <div class="form-group col-md-3"><label for="email">Event Venue</label><textarea class="form-control event_venue" name ="event_venue" placeholder="Event Venue"></textarea></div>
                                 </div>
                                 <div class="row">
                                    <div class="form-group shadow-textarea col-md-8">
                                       <label for="exampleFormControlTextarea6">Description</label>
                                      <textarea class="form-control" placeholder="Enter message" name="editor1" id="editor1" required></textarea>
                                    </div>
                                    <div class="form-group col-md-12" style="clear: both;">
                                       <button type="button" class="btn btn-default common_add" id="event" value = "Submit">Submit</button>
                                       <p id="display_mssg" class="display_mssg" style="color:red!important; font-size:17px;"></p>
                                    </div>
                              </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                  </div>
               </div>
               <div class="panel panel-default">
                  <div class="panel-heading">Applied Events</div>
                  <div class="panel-body">
                     <table class="table table-bordered myTable">
                        <thead>
                           <tr>
                              <th scope="col">Event-Title</th>
                              <th scope="col">Event-Date</th>
                              <th scope="col">Event-time</th>
                              <th scope="col">Description</th>
                              <th scope="col">Created-Date</th>
                              <th scope="col">Action</th>
                           </tr>
                        </thead>
                        <tbody id="tdetails">
                           <?php foreach($events as $events){ 
                           	date_default_timezone_set('Asia/Calcutta'); ?>
                           <tr>
                              <td><?php echo $events->type;?></td>
                              <td><?php echo $events->event_date;?></td>
                              <td><?php echo $events->event_time;?></td>
                              <td><button type="button" class="btn btn-default" onclick = getmssgdetails('<?php echo $events->event_id;?>');>View</button></td>
                              <td><?php echo date('d-m-Y',$events->created_date);?></td>
                              <td><a href="#"><i class="fa fa-edit green" aria-hidden="true" onclick="editevents('<?php echo $events->event_id; ?>')"></i></a>
                                 <i class="fa fa-trash red" aria-hidden="true" onclick="deleteevents('<?php echo $events->event_id; ?>')"></i>
                              </td>
                           </tr>
                           <?php } ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </main>
      </div>
      <div class="modal fade" id="myModal" role="dialog" style="width:100%;">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <h4 class="modal-title">Event Description</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
               </div>
               <div class="modal-body">
                  <p id="event_desc_mssg" class="event_desc_mssg"></p>
               </div>
               <div class="modal-footer">
               </div>
            </div>
         </div>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>
      <!-- Leaf Lite main scripts -->
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.5/js/bootstrap-select.js"></script>
      <script src="./assests/ajaxjs/employee_profile.js"></script>
      <script src="./assests/ajaxjs/employee_profile_insert.js"></script>
      <script>
         var button_index = $("#btn_index").val();
         
  $(document).ready( function () {

  	var editor = CKEDITOR.replace( 'editor1' );

         
             $('.myTable').DataTable({
         
               dom: 'Bfrtip',
         
                    "order": [[ 4, "desc" ]]
         
               });});
         
         
         
         $(document).ready(function(){
         
                $('.datepicker').datepicker({
         
                   dateFormat: 'yy-mm-dd',
         
                   beforeShowDay: $.datepicker.noWeekends,
                   
                   minDate: 0
         
               });
         
           $('.timepicker').timepicker({
         
             timeFormat: 'h:mm p',
         
             interval: 60,
         
             minTime: '11',
         
             maxTime: '9:00pm',
         
             defaultTime: '11',
         
             startTime: '10:00',
         
             dynamic: false,
         
             dropdown: true,
         
             scrollbar: true
         
             });
         
         });
         
         
         
         
         
         
         
         function getmssgdetails(id){
         
            $.ajax({
         
           type:"POST",
         
           url:"<?php echo base_url(); ?>AdminDashboard/getmssgdetails",
         
           data:{
         
             "id":id,
         
          },
         
           dataType:'json',
         
         success:function(response){
         
           console.log(response);
         
           $.each(response,function(key,value){
         
             $(".event_desc_mssg").html(value.event_desc);
         
           });
         
           $("#myModal").modal('show');
         
         }
         
         });
         
         }
         
         
         
         function editevents(id){
         
           window.scrollTo(300,100);
         
           $.ajax({
         
             type:"POST",
         
               url:"<?php echo base_url();?>AdminDashboard/geteventsdetails",
         
            data:{
         
               "id":id,
         
           },
         
                 dataType:'json',
         
           success:function(response){
         
             console.log(response);
         
           $.each(response,function(key,value){
         
             $(".id").val(value.event_id);
         
             $(".event_title").val(value.event_title);
         
             $(".event_date").val(value.event_date);
         
             $(".event_time").val(value.event_time);

             $(".event_venue").html(value.event_venue);

             CKEDITOR.instances.editor1.setData(value.event_desc);
                           
         
           });
         
           }
         
           });
         
         }


         
         
         
         
         
         function deleteevents(id){
         
             if(confirm("Are you sure want to delete!")){
         
         $.ajax({
         
           type:"POST",
         
         url:"<?php echo base_url(); ?>AdminDashboard/del_event",
         
          data:{
         
             "id":id,
         
         },
         
         dataType:'json',
         
         success:function(response){
         
           console.log(response);
         
          $(".display_mssg").html("Records successfully deleted");
         
           setTimeout(function(){
         
             location.reload();
         
           },3000);
         
         }
         
         });
         
         }
         
         }
         
      </script>
   </body>
</html>