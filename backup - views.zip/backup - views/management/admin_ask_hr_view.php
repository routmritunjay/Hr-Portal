 <!DOCTYPE html>
 <html lang="en">
 <head><meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
   
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
   <meta name="author" content="Łukasz Holeczek">
   <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
   <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
   <title>Intelexsystemsinc.com</title>
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
   <!-- Icons -->

   <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
   <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
     
   <!-- Main styles for this application -->
   <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
   <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
   <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
   <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
   <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
   <!-- Styles required by this views -->
    <style>
    select:invalid { color: gray; };
    .shadow-textarea textarea.form-control::placeholder {font-weight: 300;}
    .shadow-textarea textarea.form-control {padding-left: 0.8rem;}
 </style>
 
 </head>
 
 
 <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
   <div class="app-body">
     <main class="main mainbg">
       <ol class="breadcrumb breadcrumbbg">
         <li class="breadcrumb-item">Home</li>
         <li class="breadcrumb-item">Dashboard</li>
         <li class="breadcrumb-item active">Askhr</li>
       </ol>
 
       <div class="container-fluid dashboradbg">
        <div class="animated fadeIn">
          <div class="row">
            <div class="col-md-12">
              <p id="ins_errors" style="color:red;"></p>
            <div class="panel panel-default">
              <div class="panel-heading">Inquiry Records</div>
              <div class="panel-body">
                <table class="table table-bordered myTable">
                  <thead>
                    <tr>
                      <th scope="col">Inquiry-Subject</th>
                      <th scope="col">Inquiry-Description</th>
                      <th scope="col">Hr-reply</th>
                      <th scope="col">Updated-on</th>
                       <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody id="tdetails">
                    <?php foreach($ask_hr as $ask_hr){ ?>
                    <tr>
                       <td><?php echo $ask_hr->subject; ?></td>
                      <td><button type="button" class="btn btn-default" onclick = getmssgdetails('<?php echo $ask_hr->id;?>');>View Inquiry</button></td>
                       <?php if($ask_hr->reply_status == 'N'){ ?>
                      <td><button type="button" class="btn green" onclick = getreply('<?php echo $ask_hr->id;?>');></i>Reply</button></td>
                      <?php }else{ ?>
                      <td><?php echo $ask_hr->hr_reply; ?></td>
                      <?php } ?>
                      <td><?php echo $ask_hr->updated_at; ?></td>
                      <td><a><i class="fa fa-edit green" aria-hidden="true" onclick="getreply('<?php echo $ask_hr->id; ?>')"></i></a></td>
                    </tr>
                      <?php } ?>
                  </tbody>
                  </table>
                  </table>
              </div>
            </div>
           </div>
           </div>
            </div>
            </div>
          </div>
        </div>
             </div>
           </div>
         </div>
       </div>
     </main>
   </div>

   <div class="modal fade" id="myModal" role="dialog" style="width:100%;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Inquiry</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
         <div class="modal-body">
          <div class="row col-md-12">
           <div class="form-group shadow-textarea col-md-5">
            <label for="exampleFormControlTextarea6">Enter Reply</label>
            <input type="hidden" id="emp_id">
            <textarea class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" cols="90" placeholder="Describe Reply.."></textarea>
          </div>
      </div>
       </div>  
       <div class="modal-footer">
        <p id="leave_errors_type_ins" style="color:red;"></p>
        <button type="button" class="btn btn-success" id="ask_ins_btn" value="submit">Submit Inquiry</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>   
    </div>
  </div>
</div>


<div class="modal fade" id="myModalx" role="dialog" style="width:100%;">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
        <h4 class="modal-title">Inquiry</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
         <div class="modal-body">
          <p id="view_mssg"></p>
       </div>  
       <div class="modal-footer">
      </div>   
    </div>
  </div>
</div>
<footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
   <!-- Bootstrap and necessary plugins -->
   <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
   <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
   <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
 
   <!-- Plugins and scripts required by all views -->
   <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
 
   <!-- Leaf Lite main scripts -->
 
   <script src="<?php echo base_url();?>js/app.js"></script>
 
   <!-- Plugins and scripts required by this views -->
 
   <!-- Custom scripts required by this view -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
<script src="https://rawgit.com/unconditional/jquery-table2excel/master/src/jquery.table2excel.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script> 
<script>
$(document).ready( function () {
   var dataTable = $('.myTable').DataTable();
   $('.datepicker').datepicker({
    format: 'dd-mm-yyyy',
 });
 });

function elogout(){
    $.ajax({
  type:"POST",
  url:"<?php echo base_url(); ?>Employeedashboard/logout",
  data:{
  },
  success:function(response){
  console.log(response);
  location.reload();
}
});
}


$(document).ready(function(){
$('#ask_ins_btn').on('click', function(e){
    var reply = $("#exampleFormControlTextarea6").val();
     var btn_value = $("#ask_ins_btn").val();
    var id = $("#emp_id").val();
    console.log(btn_value);
    var errors = "";
      if(reply == ""){
            errors = "Reply field cannot be empty";
            $("#leave_errors_type_ins").html(errors);
      }
      else if(reply!= "" && btn_value == "submit"){
    $.ajax({
    type:"POST",
      url:"<?php echo base_url();?>AdminDashboard/insertask_hr",
   data:{
      "id":id,
      "reply":reply
      },
  success:function(response){
    console.log(response);
    $("#leave_errors_type_ins").html("Successfully updated").css("color", "green");
        setTimeout(function(){
            location.reload();
      },3000);
  }
  });
  }else if(btn_value == "Update"){
    $.ajax({  
    type:"POST",
    url:"<?php echo base_url();?>Employeedashboard/updateask_hr",
    data:{
        "id":id,
         "subject":subject
        },
    dataType:'json',
    success:function(response)  
    {
    console.log(response);
    $("#leave_errors_type_ins").html("Your data has been successfully updated").css("color", "green");
          setTimeout(function(){
            location.reload();
      },3000);
    }
  });
  }
});
});

function getmssgdetails(id,name){
   $.ajax({
  type:"POST",
  url:"<?php echo base_url(); ?>Employeedashboard/getaskmssgdetails",
  data:{
    "id":id
 },
  dataType:'json',
success:function(response){
  console.log(response);
  $.each(response,function(key,value){
    var mssg = value.ask_desc;
    $("#view_mssg").html(mssg);
  });
  $("#myModalx").modal('show');
}
});
}

function getreply(id,name){
   $.ajax({
  type:"POST",
  url:"<?php echo base_url(); ?>Employeedashboard/getaskmssgdetails",
  data:{
    "id":id
 },
 dataType:'json',
success:function(response){
  console.log(response);
  if(response.length == 0){
      $("#emp_id").val(id);
  }else{
  $.each(response,function(key,value){
    var mssg = value.hr_reply;
    $("#exampleFormControlTextarea6").html(mssg);
    $("#emp_id").val(id);
  });
  $("#myModal").modal('show');
}}
});
}

$("#reset_opt").click(function(){
location.reload();
});

</script>
 </body>
 </html>