<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <!-- Styles required by this views -->
      <style>
         p{
         color:green;
         }
         select:invalid { color: gray; }
      </style>
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Admin</li>
               <li class="breadcrumb-item active">Attendance</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <div class="row">
                     <div class="col-sm-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Attendance</div>
                           <div class="panel-body" style="overflow: hidden;">
                              <p id="filteration_err" style="color:red;"></p>
                              <input type="hidden" id="roles" value="<?php echo $role; ?>">
                              <div class="col-sm-12 col-md-12" style="display: inline-flex;">
                                 <div class="col-sm-3">
                                    <select name="job_role" class="form-control" id="name_filter">
                                       <option value="">Select an Employee</option>
                                       <?php foreach($all_emp as $all_emp){ ?>
                                       <option value="<?php echo $all_emp->uniqueID; ?>"><?php echo $all_emp->first_name; ?><?php echo $all_emp->last_name; ?></option>
                                       <?php } ?>
                                    </select>
                                 </div>
                                 <div class="col-sm-3" autocomplete="off">
                                    <input type="text" class="form-control datepicker to_date" name ="to_date" id ="to_date" placeholder="Start date">
                                 </div>
                                 <div class="col-sm-3" autocomplete="off">
                                    <input type="text" class="form-control datepicker to_date" name ="end_date" id="end_date" placeholder="End date">
                                 </div>
                                 <div class="col-sm-3">
                                    <button type="button" class="btn green" id="attendence_filter_options"><i style="font-size:17px" class="fa">&#xf0b0;</i></button>
                                    <button type="button" class="btn green" id="reset_opt"><i style="font-size:17px" class="fa">&#xf021;</i></button>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col-sm-3 wrkng_prtl">
                        <h5>
                           Hours to be Spent:-
                           <p id="ttl_hrs"></p>
                        </h5>
                        <br>
                     </div>
                     <div class="col-sm-3 wrkng_prtl">
                        <h5>
                           Total Hours Spent:-
                           <p id="Hours_spent"></p>
                        </h5>
                        <br>
                     </div>
                     <div class="col-sm-3 wrkng_prtl">
                        <h5>
                           Deficit Hours:-
                           <p id="deficit_hrs"></p>
                        </h5>
                     </div>
                     <div class="col-sm-3 wrkng_prtl">
                        <h5>
                           Extra Hours:-
                           <p id="extra_hrs"></p>
                        </h5>
                     </div>
                  </div>
               </div>
               <div class="panel panel-default">
                  <div class="panel-heading">Time-Sheet</div>
                  <div class="panel-body">
                     <table class="table table-bordered myTable" id="myTable">
                        <thead>
                           <tr class="noExl">
                              <th scope="col">Attendance-Date</th>
                              <th scope="col">Employee-Name</th>
                              <th scope="col">Login-Time</th>
                              <th scope="col">Logout-Time</th>
                              <th scope="col">Total-Working-Hours</th>
                              <th scope="col">Deficient-Hours</th>
                              <th scope="col">Extra-Hours</th>
                              <th scope="col">Updated-on</th>
                           </tr>
                        </thead>
                        <tbody id="tdetails">
                           <?php foreach($payroll_res as $payroll_res){ 

                        if($payroll_res->attendence_date != '' && $payroll_res->attendence_date != 0) {

                        date_default_timezone_set('Asia/Kolkata');

                        $working_hrs_arr = explode(":",$payroll_res->total_working_hrs);

                           $time_diff = ($working_hrs_arr[0] >= 9) ? floor((strtotime($payroll_res->total_working_hrs) - strtotime('9:00'))/60) : floor((strtotime('9:00') - strtotime($payroll_res->total_working_hrs))/60);

                           $hr = (floor($time_diff/60) < 10) ? '0'.floor($time_diff/60) : floor($time_diff/60);

                           $min = (($time_diff % 60) < 10) ? '0'.($time_diff % 60) : ($time_diff % 60);

                           if($working_hrs_arr[0] < 9){

                             $deficit_hrs = $hr .":".$min.":00";

                              $extra_hrs = "00:00:00";

                           }else{

                              $deficit_hrs = "00:00:00";

                              $extra_hrs = $hr .":".$min.":00";

                           }
                  ?>
                           <tr>
                              <td><?php echo date('d-m-Y',$payroll_res->attendence_date) ; ?></td>
                              <td><?php echo $payroll_res->first_name;?></td>
                              <td><?php echo $payroll_res->login_time;?></td>
                              <td><?php echo $payroll_res->logout_time;?></td>
                              <td><?php echo $payroll_res->total_working_hrs;?></td>
                              <td><?php echo ($payroll_res->login_time == "" && $payroll_res->logout_time == "") ? "00:00:00" : $deficit_hrs;?></td>
                              <td><?php echo ($payroll_res->login_time == "" && $payroll_res->logout_time == "") ? "00:00:00": $extra_hrs;?></td>
                              <td><?php echo $payroll_res->updated_on;?></td>
                           </tr>
                           <?php } ?>
                           <?php } ?>
                        </tbody>
                        <tfoot id="tfoot">
                           <tr>
                              <td>Hour to be spent</td>
                              <td id="tspent"></td>
                              <td>Total Hours Spent</td>
                              <td id="hspent">
                              <td>Deficit Hours</td>
                              <td id="defhrs">
                              <td>Extra Hours</td>
                              <td id="exthrs">
                           </tr>
                        </tfoot>
                     </table>
                  </div>
               </div>
            </div>
      </div>
      </main>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <!-- Leaf Lite main scripts -->
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="<?php echo base_url();?>js/views/.main.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="https://rawgit.com/unconditional/jquery-table2excel/master/src/jquery.table2excel.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
      <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>
      <script>
         $(document).ready( function () {
             $("#tfoot").hide();
           $(".wrkng_prtl").hide();
             var dataTable = $('.myTable').DataTable({

               "aaSorting": [],
               dom: 'lBfrtip',
                 buttons: [
                     {
                   extend: 'pdf',
                   footer: true,
                   },
                     {
                   extend: 'excel',
                   footer: true,}
                 ],
              });
             $('.datepicker').datepicker({
               dateFormat: 'yy-mm-dd',
               beforeShowDay: $.datepicker.noWeekends
             });
             });
         
         
      </script>
   </body>
</html>