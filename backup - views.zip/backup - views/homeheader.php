<header class="app-header navbar">
     <button class="navbar-toggler mobile-sidebar-toggler d-lg-none mr-auto" type="button">
       <span class="navbar-toggler-icon"></span>
     </button>
     <?php if(ISSET($role)) { ?>
      <?php if($role == 1 || $role == 5  || $role == 4 || $role == 7 || $role == 6) { ?>
     <a class="navbar-brand" href="dashboard">
       <img src="<?php echo base_url(); ?>img/dashboard-logo.png" class="logo" />
     </a>
      <?php }else if($role == 2 || $role == 0 || $role == 3 || $role == 6){?>
      <a class="navbar-brand" href="<?php echo base_url(); ?>dashboard">
       <img src="<?php echo base_url(); ?>img/dashboard-logo.png" class="logo" />
     </a>
      <?php } ?>
     <?php } ?>
     <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button">
       <span class="navbar-toggler-icon"></span>
     </button>
    <?php if($role == 2 || $role == 0 || $role == 3 || $role == 6 || $role == 7 || $role == 1 || $role == 4){?>
     <h6 class="username" style="padding:5px 0px 0px 0px">Welcome  <?php echo $full_name; ?></h6>
     <?php } ?>
     <ul class="nav navbar-nav ml-auto logout">
     	<?php if(ISSET($role)) { ?>
         <?php if($role == 1 || $role == 5  || $role == 4 || $role == 7 ) { ?>
       <li class="nav-item dropdown">
         <a class="nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
           <button><i class="fa fa-user"></i> Logout </button>
         </a>
         <div class="dropdown-menu dropdown-menu-right">
           <div class="dropdown-header text-center">
             <strong>Settings</strong>
           </div>
           <a class="dropdown-item" href="<?php echo base_url(); ?>Adminprofile"><i class="fa fa-user"></i> Profile</a>
          
           <a class="dropdown-item" href="<?php echo base_url(); ?>AdminDashboard/logout"><i class="fa fa-lock"></i> Logout</a>
         </div>
       </li>
        <?php }else if($role == 2 || $role == 0 || $role == 3 || $role == 6){?>
        <div class='pull-left'>
        
      </div>
       <li class="nav-item dropdown">
         <a class="nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
           <button><i class="fa fa-user"></i> Logout </button>
         </a>
         <div class="dropdown-menu dropdown-menu-right">
           <div class="dropdown-header text-center">
             <strong>Settings</strong>
           </div>
           <a class="dropdown-item" href="<?php echo base_url(); ?>Employeeprofile"><i class="fa fa-user"></i> Profile</a>
          
           <a class="dropdown-item" href="<?php echo base_url(); ?>AdminDashboard/logout" ><i class="fa fa-lock"></i> Logout</a>
         </div>
       </li>
       <?php } ?>
       <?php } ?>
     </ul>
   </header>


  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8.13.6/dist/sweetalert2.all.min.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/insertajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/leave_filter_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/validationajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/common_update_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/timesheet_approval_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/timesheet_filter_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/forgot_pwd_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/delete_roles_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/attendence/attendence_filter_ajax.js"></script>

    <script src="<?php echo base_url();?>assests/ajaxjs/work_tracker/work_tracker_filtration_ajax.js"></script> 


    <script>
         $(document).ready(function() {

            $('.multiselect-ui').multiselect({

                    nonSelectedText: 'Select Employee',

                     includeSelectAllOption: true,
                     
                      maxHeight: 100,

                      numberDisplayed: 1,

                      dropRight: true,

                      preventInputChangeEvent: true


               });

             $('.ltype_multiselect-ui').multiselect({

                    nonSelectedText: 'Select Leave Type',

                     includeSelectAllOption: true,

                      maxHeight: 100,

                      numberDisplayed: 1,

                      dropRight: true,

                      preventInputChangeEvent: true


               });

               $('.pname_multiselect-ui').multiselect({

                    nonSelectedText: 'Select Project Name',

                     includeSelectAllOption: true,

                      maxHeight: 100,

                      numberDisplayed: 1,

                      dropRight: true,

                      preventInputChangeEvent: true


               });

               $('.status_multiselect-ui').multiselect({

                    nonSelectedText: 'Select Status',

                     includeSelectAllOption: true,

                      maxHeight: 100,

                      numberDisplayed: 1,

                      dropRight: true,

                      preventInputChangeEvent: true


               });



            });




      </script>         

