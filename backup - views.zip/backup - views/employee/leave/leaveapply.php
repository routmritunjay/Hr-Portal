<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link rel="<?php echo base_url();?>stylesheet" href="css/bootstrap.css">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_editor.min.css' rel='stylesheet' type='text/css' />
      <link href='https://cdnjs.cloudflare.com/ajax/libs/froala-editor/2.8.1/css/froala_style.min.css' rel='stylesheet' type='text/css' />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/css/bootstrap-multiselect.css">
      <!-- Styles required by this views -->
      <style type="text/css">
         .removebttn{margin-top: 28px;}
      </style>
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Dashboard</li>
               <li class="breadcrumb-item active">Leave</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <a href="<?php echo base_url(); ?>Available_leave" class="btn green" role="button">View Remaining Leaves</a>
                  <div class="row">
                     <div class="col-md-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Apply Leave</div>
                           <div class="panel-body" style="overflow: hidden;">
                              <form name="MyForm" autocomplete="off" id="form_dt">
                                 <div class="row">
                                    <div class="form-group col-md-4">
                                       <input type="hidden" id="res_date">
                                       <input type="hidden" id="btn_cntr_val">
                                       <input type="hidden" id="btn_index">
                                       <input type="hidden" id="roles" value="<?php echo $role; ?>">
                                       <input type="hidden" id="em_id" value="<?php echo $id; ?>">
                                       <input type="hidden" class="name_filter" value = "<?php echo $id; ?>">
                                       <p id="leave_type_errors" style="color:red!important; font-size:18px;"></p>
                                       <label for="email">Leave type</label>
                                       <select class="form-control" id="leave_type" name= "leave_type" onchange="getleaverow();">
                                          <option value="">Select an Option</option>
                                          <?php foreach($leave_type as $leave_type){?>
                                          <option value="<?php echo $leave_type->leave_unique_id; ?>"><?php echo $leave_type->leave_type; ?></option>
                                          <?php } ?>
                                       </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                       <div style = "padding: 45px 0 0 0;" >
                                          <button type="button" class="btn green getbtnleavedate" onclick="getleavedate();"><i class="fa fa-plus"></i></button>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="button_rows">
                                 </div>
                                 <div class="row">
                                    <div class="form-group col-md-12">
                                       <label for="email">Message</label>
                                       <textarea class="form-control" id="editors" placeholder="Enter message" name="editor1" id="editor1" required></textarea>
                                    </div>
                                 </div>
                                 <div class="form-group col-md-12" style="clear: both;">
                                    <input type="button" class="btn btn-success common_add" id="leave_apply" value="Submit Request">
                                    <p id="leave_errors" style="color:#FF0000!important; font-size:18px;"></p>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12">
                     <p id="filteration_err" style="color:red;"></p>
                     <div class="panel panel-default">
                        <div class="panel-heading">Leave Filter</div>
                        <p></p>
                        <div class="col-sm-12 col-md-12" style="display: inline-flex;">
                           <div class="col-sm-3">
                              <select class="form-control ltype_multiselect-ui leave_type" id="leaves_type" name= "leaves_type" onchange="getleaverow();" multiple="multiple">
                                 <?php foreach($leaves_type as $leaves_type){?>
                                 <option value="<?php echo $leaves_type->leave_unique_id; ?>"><?php echo $leaves_type->leave_type; ?></option>
                                 <?php } ?>
                              </select>
                           </div>
                           <div class="col-sm-3" autocomplete="off">
                              <input type="text" class="form-control datepicker to_date" name ="to_date" id ="to_date" placeholder="Start date">
                           </div>
                           <div class="col-sm-3" autocomplete="off">
                              <input type="text" class="form-control datepicker to_date" name ="end_date" id="end_date" placeholder="End date">
                           </div>
                           <div class="col-sm-3">
                              <button type="button" class="btn green" id="leave_filter_options"><i style="font-size:17px" class="fa">&#xf0b0;</i></button>
                              <button type="button" class="btn green" id="reset_opt"><i style="font-size:17px" class="fa">&#xf021;</i></button>
                           </div>
                           <p id="filteration_err" style="color:red;"></p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="panel panel-default">
                  <div class="panel-heading">Applied Leave</div>
                  <div class="panel-body">
                     <table class="table table-bordered myTable">
                        <thead>
                           <tr>
                              <th scope="col">Leave-type</th>
                              <th scope="col">Leave-Pattern</th>
                              <th scope="col" nowrap>Start-Date</th>
                              <th scope="col" nowrap>End-Date</th>
                              <th scope="col" nowrap>No-of-Days</th>
                              <th scope="col">Message</th>
                              <th scope="col">Applied-Date</th>
                              <th scope="col">Manager-Approval</th>
                              <th scope="col">CEO-Approval</th>
                              <th scope="col">Manager-Comments</th>
                              <th scope="col">CEO-Comments</th>
                              <th scope="col">Action</th>
                           </tr>
                        </thead>
                        <tbody id="tdetails">
                           <?php foreach($leavedetails as $leavedetails){ ?>
                           <tr>

                              <td><?php echo (is_numeric($leavedetails->leave_type_employee)) ? $leavedetails->leave_type : $leavedetails->leave_type_employee;?></td>


                              <td><?php echo ($leavedetails->leave_pattern != "") ? $leavedetails->leave_pattern : 'N/A';?></td>

                              <td><?php echo ($leavedetails->leave_from_date != "") ? $leavedetails->leave_from_date : 'N/A';?></td>

                              <td><?php echo ($leavedetails->leave_to_date != "") ? $leavedetails->leave_to_date : 'N/A';?></td>

                              <td><?php echo ($leavedetails->total_days != "") ? $leavedetails->total_days : 'N/A';?></td>

                              
                              <td><button type="button" class="btn btn-default" onclick = "getleavemssgdetails('<?php echo $leavedetails->leave_id;?>','<?php echo $leavedetails->applicant_email;?>')";>View</button></td>


                              <td><?php echo $leavedetails->appiled_date;?></td>


                              <td><?php echo ($leavedetails->manager_approval == 'approved' ? '<a href="#" class="green"><i class="fa">&#xf00c;</i></a>' :($leavedetails->manager_approval == 'rejected'  ? '<a href="#" class="red"><i class="fa">&#xf00d;</i></a>' : '<i class="fa fa-clock-o" aria-hidden="true">' )) ?></td>
                              <td><?php echo ($leavedetails->ceo_approval == 'approved'  ? '<a href="#" class="green"><i class="fa">&#xf00c;</i></a>' : ($leavedetails->ceo_approval == 'rejected' ? '<a href="#" class="red"><i class="fa">&#xf00d;</i></a>' : '<i class="fa fa-clock-o" aria-hidden="true">' )) ?></td>

                              <td><?php echo ($leavedetails->manger_comments == '') ? 'N/A' : $leavedetails->manger_comments?></td>

                              <td><?php echo ($leavedetails->ceo_comments == '')  ? 'N/A' : $leavedetails->ceo_comments?></td>

                              <td><?php echo ($leavedetails->manager_approval == 'approved' || $leavedetails->ceo_approval == 'approved' || $leavedetails->manager_approval == 'rejected' || $leavedetails->ceo_approval == 'rejected') ?'<a href="#" class="disabled"><i class="fa fa-edit green" rel="tooltip" title="Action Inactive" aria-hidden="true"></i></a><i class="fa fa-trash red" aria-hidden="true" rel="tooltip" title="Action Inactive"></i>':'<a href="'.base_url().'leaveedit?id='.$leavedetails->leave_id.'""><i class="fa fa-edit green" rel="tooltip" title="Key Active" aria-hidden="true"></i></a><i class="fa fa-trash red" aria-hidden="true" onclick=comment_delete_func("'.$leavedetails->leave_id.'","emp_leave")></i>'?></td>
                           </tr>
                           <?php } ?>
                        </tbody>
                     </table>
                  </div>
               </div>
            </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </main>
      </div>
      <div class="modal fade" id="myModal" role="dialog" style="width:100%;">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <h4 class="modal-title">Message</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
               </div>
               <div class="modal-body">
                  <h4 id="view_mssg_res"></h4>
                  <p id="view_mssg"></p>
               </div>
               <div class="modal-footer">
               </div>
            </div>
         </div>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>
      <!-- Leaf Lite main scripts -->
      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.15/js/bootstrap-multiselect.min.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
      <script src="<?php echo base_url();?>assests/ajaxjs/leave_ajax.js"></script>
      <script src="<?php echo base_url();?>assests/ajaxjs/common_delete_ajax.js"></script>
      <script>
         var editor = CKEDITOR.replace( 'editor1' );
         $(document).ready( function () {
         
             $('.myTable').DataTable({

               "aaSorting": [],

               });
               $("[rel=tooltip]").tooltip({ placement: 'right'});
         });
            
         
         
         $("#reset_opt").click(function(){  location.reload();  });
         
         function getleaverow(){
           $(".leave_apply_row").empty();
           $("#btn_index").val(0)
           $("#btn_cntr_val").val(0);
               $(".leave_pattern_types").empty();
                $("#leave_type_errors").empty();
               $("#leave_errors").html('');
               $(".fromdate").empty();
               $(".todate").empty();
               $(".remove_btn").empty();
         }


         function CKupdate(){
           CKEDITOR.instances.editors.setData('');
         }
         
         
      </script>
   </body>
</html>