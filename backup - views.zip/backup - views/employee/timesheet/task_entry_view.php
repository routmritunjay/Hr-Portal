<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="Leaf Lite - Free Bootstrap Admin Template">
      <meta name="author" content="Łukasz Holeczek">
      <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,AngularJS,Angular,Angular2,Angular 2,Angular4,Angular 4,jQuery,CSS,HTML,RWD,Dashboard,React,React.js,Vue,Vue.js">
      <link rel="shortcut icon" href="<?php echo base_url();?>login/images/favicon.png">
      <title>Intelexsystemsinc.com</title>
      <!-- Icons -->
      <link href="<?php echo base_url();?>vendors/css/font-awesome.min.css" rel="stylesheet">
      <link href="<?php echo base_url();?>vendors/css/simple-line-icons.min.css" rel="stylesheet">
      <!-- Main styles for this application -->
      <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet">
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <link href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css" rel="stylesheet" type="text/css" />
      <link href="<?php echo base_url();?>css/dashboard.css" rel="stylesheet">
      <link href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/css/bootstrap-datetimepicker.min.css" />
      <!-- Styles required by this views -->
   </head>
   <body class="app header-fixed sidebar-fixed aside-menu-fixed aside-menu-hidden">
      <div class="app-body">
         <main class="main mainbg">
            <ol class="breadcrumb breadcrumbbg">
               <li class="breadcrumb-item">Home</li>
               <li class="breadcrumb-item">Dashboard</li>
               <li class="breadcrumb-item active">Task_Entry</li>
            </ol>
            <div class="container-fluid dashboradbg">
               <div class="animated fadeIn">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="panel panel-default">
                           <div class="panel-heading">Entry Task</div>
                           <div class="panel-body" style="overflow: hidden;">
                              <form name="MyForm" id="form_dt" autocomplete="off">
                                 <div class="row">
                                    <?php if(!empty($edittask)){ ?>
                                    <?php foreach($edittask as $edit) { ?>
                                    <div class="form-group col-md-3">
                                       <input type="hidden" id="btn_cntr_val_task" value ="<?php echo $edit->task_id; ?>">
                                       <label for="ProjectName">Project Name</label>

                                       <select type="select" class="form-control project_name_val" id="name_filter">

                                       <option value="<?php echo $edit->project_name; ?>"><?php echo ($edit->name == "" ) ? $edit->project_name : $edit->name; ?>(<?php echo $edit->project_name; ?>)</option>
                                       <?php foreach($project_name as $project_name){

                                          if ($edit->project_name != $project_name->project_code) { ?>
                                          <option value="<?php echo $project_name->project_code; ?>"><?php echo $project_name->name; ?>(<?php echo $project_name->project_code; ?>)</option>
                                       <?php } }?>
                                        </select>

                                    </div>
                                    <div class="form-group col-md-3">
                                       <label for="email">Date</label>
                                       <input type = "text" class="form-control datepicker task_date" autocomplete="off" name ="task_date" id="up_task_date" value ="<?php echo date("m/d/Y",$edit->task_date); ?>" onkeydown="return false;">
                                    </div>
                                    <div class="form-group col-md-12">
                                       <label for="email">Task Description</label>
                                        <textarea class="form-control" id="editors" placeholder="Enter message" name="editor1" id="editor1" required><?php echo $edit->task_description; ?></textarea>
                                    </div>
                                    <div class="form-group col-md-4 status">
                                       <label for="email">Status</label>
                                       <select class="form-control status_val" id="up_status_val" name= "status_val">
                                          <option value="<?php echo $edit->status; ?>"><?php echo ucwords($edit->status); ?></option>
                                          <?php if($edit->status == "completed"){ ?>
                                          <option value="inprogress">In-progress</option>
                                          <option value="Inhold">In-hold</option>
                                       </select>
                                       <?php } else if($edit->status == "inprogress"){ ?>
                                       <option value="completed">Completed</option>
                                       <option value="Inhold">In-hold</option>
                                       <?php } else if($edit->status == "Inhold"){ ?>
                                       <option value="completed">Completed</option>
                                       <option value="inprogress">In-progress</option>
                                       <?php } ?>
                                       </select>
                                    </div>
                                    <div class="form-group col-md-4">
                                       <input type="hidden" id="btn_cntr_val">
                                       <label for="ProjectName">Total Time Spent</label>
                                       <input type="number" name="time_spent" class="form-control time_spent" placeholder="Enter Time Spent" value="<?php echo $edit->total_time_spent; ?>">
                                    </div>
                                 </div>
                                 <?php } ?>
                                 <?php }else{ ?>
                                 <div class="form-group col-md-3">
                                    <input type="hidden" id="btn_cntr_val">
                                    <label for="ProjectName">Project Name</label>
                                    <select name="job_role" class="form-control project_name_val" class="project_name_val" placeholder="Enter Project Name">
                                       <option value = "none">Select An Project Name</option>
                                       <?php foreach($project_name as $project_name){ ?>
                                          <option value="<?php echo $project_name->project_code; ?>"><?php echo $project_name->name; ?>(<?php echo $project_name->project_code; ?>)</option>
                                           <?php } ?>
                                    </select>
                                 </div>
                                 <div class="form-group col-md-3">
                                    <input type="hidden" id="btn_cntr_val">
                                    <label for="email">Date</label>
                                    <input class="form-control datepicker task_date" autocomplete="off" name ="task_date" placeholder="Task Date" onkeydown="return false;">
                                 </div>
                                 <div class="form-group col-md-9">
                                    <label for="email">Task Description</label>

                                   <textarea class="form-control" id="editors" placeholder="Enter message" name="editor1" id="editor1" required></textarea>
                                 </div>
                                 <div class="form-group col-md-4 status">
                                    <label for="email">Status</label>
                                    <select class="form-control status_val" id="status_val" name= "status_val">
                                       <option value="">Select an Option</option>
                                       <option value="completed">completed</option>
                                       <option value="inprogress">In-progress</option>
                                       <option value="Inhold">In-hold</option>
                                    </select>
                                 </div>
                                 <div class="form-group col-md-4">
                                    <label for="ProjectName">Total Time Spent</label>
                                    <input type="number" onkeydown="javascript: return event.keyCode == 69 ? false : true" name="time_spent" class="form-control time_spent" placeholder="Enter Time Spent">
                                 </div>
                                 <?php } ?>
                              </form>
                           </div>
                        </div>
                     </div>
                     <?php if(ISSET($edittask) && !empty($edittask)) { ?>
                     <div class="form-group col-md-12" style="clear: both;">
                        <input type="button" class="btn btn-success common_update" id="up_timesheet_entry" value="Update Request">
                        &nbsp<a href="<?php echo base_url();?>Timesheet"><input type="button" class="btn btn-success" id="reset_opt" value="Back" ></a>
                        <p id="leave_errors" style="color:red; font-size:15px;"></p>
                     </div>
                     <?php }else{ ?>
                     <div class="form-group col-md-12" style="clear: both;">
                        <input type="button" class="btn btn-success common_add" id="timesheet_entry" value="Submit Request"> <input type="button" class="btn btn-success" id="reset_opt" value="Reset">&nbsp<input type="button" class="btn btn-success" id="reset_opt" value="Back" onclick="back()"> 
                        <p id="leave_errors" style="color:red; font-size:15px;"></p>
                     </div>
                     <?php } ?>
                  </div>
               </div>
            </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      </main>
      </div>
      <div class="modal fade" id="myModal" role="dialog" style="width:100%;">
         <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Message</h4>
               </div>
               <div class="modal-body">
                  <h4 id="view_mssg_res"></h4>
                  <p id="view_mssg"></p>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      <footer class="app-footer footerbg text-center">Intelex Systems © 2018 Intelex Systems Inc. </footer>
      <!-- Bootstrap and necessary plugins -->
      <script src="<?php echo base_url();?>vendors/js/jquery.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/popper.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/pace.min.js"></script>
      <!-- Plugins and scripts required by all views -->
      <script src="<?php echo base_url();?>vendors/js/Chart.min.js"></script>
      <!-- Leaf Lite main scripts -->
  <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

      <script src="<?php echo base_url();?>js/app.js"></script>
      <!-- Plugins and scripts required by this views -->
      <!-- Custom scripts required by this view -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
      <script src="http://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
      <script src="<?php echo base_url();?>vendors/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script> 
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
      <script>
                     var editor = CKEDITOR.replace( 'editor1' );

         $(document).ready( function () {

          var holidays = getholiday_list();

         $('.datepicker').datepicker({

             format: 'dd-mm-yy',

             beforeShowDay: $.datepicker.noWeekends,
             
             firstDay:1,
             
             beforeShowDay: function (date) {

               var datestring = jQuery.datepicker.formatDate('yy-mm-dd', date);
         
               var monday = new Date();
         
                monday.setHours(0,0,0,0);
         
                 monday.setDate(monday.getDate() + 1 - (monday.getDay() || 7));
         
                 var saturday = new Date(monday);
         
                  saturday.setDate(monday.getDate() + 5);
         
                  return [date >= monday && date < saturday && holidays.indexOf(datestring) == -1];
               }
           });
         
         });
         
         function back(){


               window.location.href = window.location.origin + "/login/"+"Timesheet";
         }
        
         
         function valid_pro_name(){
         $("#leave_errors").empty();
         }
         
         $("#reset_opt").click(function(){
         window.location.href="<?php echo base_url(); ?>Timesheet"
         });

         function CKupdate(){
  CKEDITOR.instances.editors.setData('');
}


function getholiday_list(){

      var jqXHr =  $.ajax({

           type:"POST",

           url:"<?php echo base_url(); ?>Timesheet/holiday_list",

           data:{},

           dataType:'json',

           async: false,

         success:function(response){

            return response;
          
         }


      });

      return jqXHr.responseText;
   }

      </script>
   </body>
</html>